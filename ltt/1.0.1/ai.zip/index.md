# Home - LTT Implementation Guide v1.0.1

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://fhir.kl.dk/ltt/ImplementationGuide/kl.dk.fhir.ltt | *Version*:1.0.1 |
| Active as of 2025-10-29 | *Computable Name*:LTT |

# LTT - KL Lettilgængeligt tilbud

This implementation guide describes the delivery of LTT data to KL Gateway. The data originates from the documentation on the activity in LTT in the Danish municipalities. The reporting aims for compliance with the Danish core profiles.

The profiles for the reporting are restricted to allow only the information that is required to report to KL Gateway.

## Overview

The data is reported as a collection of instances. A report contain instances that conforms to the profiles defined in this implementation guide. See figure below.

![](./ReportStructure.png)

In addition to being structured as a report, relationships exist between the profiles. These are illustrated in the UML Class Diagram in the figure below.

![](./ClassDiagram.png)

The Class diagram shows that CarePlan, Encounter and Referral are all associated with Citizen i.e. these profiles know which Citizen they hold information about. The Encounter and Referral are also associated with the CarePlan.

The Citizen profile inherit from dk-core, even though it is not illustrated specifically in the Class Diagram.

## Special constraints, and resulting reporting practises

Whereas the report may seem unconstrained, each profile define constraints on attributes, datatypes and cardinalities. See descriptions below.

## Citizen

Information about the citizens that are the subjects of the report. This resource is used to get a reference to the child or youth.

##### Attributes

* civil registration number (CPR-nr).
* identification of the municipality holding and reporting the data.
* a FHIR status attribute used to report errors.

##### Validation

* One and only one civil registration number exists, and is a syntactically valid CPR-nr.
* One and only one managing organization exists, and is a syntactically valid SOR code (only code length is currently validated in the profile, but the authorization validates the actual SOR code).
* One FHIR status may exist, and should be selected from the standard ValueSet.

## CarePlan

This model contains information about the treatment pathway from the child’s or youths first encounter with the municipality concerning LTT.

##### Attributes

* A start time.
* An end time.
* A code that decribes which care plan it is.
* A reference to the Citizen instance that holds the child or youth's information.
* A reasonCode that describe the focus area which is the reason for the care plan and encounters.
* Three FHIR status attributes (status, intent, activity.detail.status).

##### Validation

* One and only one code exists and should be selected from a specific ValueSet.
* One and only one start time.
* One and only one reference to the Citizen exists.
* The reasonCode is optional. If present, it should be selected from a specific ValueSet. It is allowed to have more than one reasonCode.
* The FHIR status attributes are mandatory, and should be selected from the standard FHIR ValueSet.

## Encounter

Information about when a child or youth have an encounter such as screenings, prelimerary interviews, treatments, etc. in a Danish municipality context.

##### Attributes

* Type of encounter. The attribute describe which encounter is delivered using a code.
* Encounter class. The attribute holds a code which describe the place of delivery.
* The encounter start time.
* A reference to the Citizen instance that holds the child or youth's information.
* A FHIR status attribute.
* The participant of the encounter. It can be the child or youth itself or its parents.
* A delivery type code that express whether the encounter is delivered in a group or individually.
* A reference to the CarePlan instance the Encounter is a part of.

##### Validation

* One and only one encounter type exists, and should be selected from a specific ValueSet, no other codes may be reported.
* One and only one encounter class exists, and should be selected from a specific ValueSet.
* One and only one encounter start time exists.
* One and only one reference to the Citizen exists.
* One and only one reference to the CarePlan exists.
* One and only one FHIR status exists, and should be selected from the standard FHIR ValueSet.
* One delivery type code, which should be selected from a specific ValueSet, may exist.
* One participant code, which should be selected from a specific ValueSet, may exist.

## Referral

Referrals in this context are informal recommendations to other parties, such as the child’s or youth’s general practitioner, a §126a service in another municipality, and similar instances.

##### Attributes

* A code indicating which service the citizen is being referred to.
* A start time.
* A reference to the Citizen instance that holds the child or youth's information.
* A reference to the CarePlan instance that this referral is a part of.
* Three FHIR status attributes (status, intent, activity.detail.status).

##### Validation

* One and only one code is mandatory and should be selected from the specified ValueSet.
* One and only one start time.
* One and only one reference to the Citizen exists.
* One and only one reference to the CarePlan exists.
* The FHIR status attributes are mandatory, and should be selected from the standard FHIR ValueSet. activity.detail.status must be set to 'completed'.

## Dependencies








## Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (kl.dk.fhir.ltt.r4)](package.r4.tgz) and [R4B (kl.dk.fhir.ltt.r4b)](package.r4b.tgz) are available.

## Global Profiles

*There are no Global profiles defined*

## IP Statements

This publication includes IP covered under the following statements.

* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [ActCode](http://terminology.hl7.org/6.5.0/CodeSystem-v3-ActCode.html): [Bundle/DeliveryReport-Josefine-1](Bundle-DeliveryReport-Josefine-1.md), [Bundle/DeliveryReport-Josefine-2](Bundle-DeliveryReport-Josefine-2.md)...Show 9 more,[Bundle/DeliveryReport-Josefine-3](Bundle-DeliveryReport-Josefine-3.md),[Bundle/DeliveryReport-Josefine-4](Bundle-DeliveryReport-Josefine-4.md),[Bundle/DeliveryReport-Josefine-5-6-7](Bundle-DeliveryReport-Josefine-5-6-7.md),[Bundle/DeliveryReport-Josefine-8](Bundle-DeliveryReport-Josefine-8.md),[Bundle/DeliveryReport-Josefine-9](Bundle-DeliveryReport-Josefine-9.md),[Bundle/RapportOmJosefine](Bundle-RapportOmJosefine.md),[Bundle/TestIncrementalDelivery](Bundle-TestIncrementalDelivery.md),[Encounter/Behandlingskontakt](Encounter-Behandlingskontakt.md)and[KLGatewayLTTEncounter](StructureDefinition-klgateway-ltt-encounter.md)



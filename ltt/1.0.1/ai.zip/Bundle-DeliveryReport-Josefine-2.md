# DeliveryReport-Josefine-2 - LTT Implementation Guide v1.0.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DeliveryReport-Josefine-2**

## Example Bundle: DeliveryReport-Josefine-2

Profile: [KLGatewayLTTDeliveryReport](StructureDefinition-klgateway-ltt-delivery-report.md)

Bundle DeliveryReport-Josefine-2 of type collection

-------

Entry 1 - fullUrl = https://test.fhir.dk/Patient/407ceb16-acb4-43ea-a4f5-d415c17faded

Resource Patient:

> 

Profile: [KLGatewayLTTCitizen](StructureDefinition-klgateway-ltt-citizen.md)

Anonymous Patient (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#0505149996 (use: official, ))
-------

-------

Entry 2 - fullUrl = https://test.fhir.dk/CarePlan/857ea1d6-c212-4c89-a2f4-9e2bfa8c288d

Resource CarePlan:

> 

Profile: [KLGatewayLTTCarePlan](StructureDefinition-klgateway-ltt-care-plan.md)

**status**: Active**intent**: Plan**subject**:[Anonymous Patient (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#0505149996 (use: official, ))](Bundle-DeliveryReport-Josefine-1.md#Patient_407ceb16-acb4-43ea-a4f5-d415c17faded)**period**: 2025-05-14 09:12:05+0000 --> (ongoing)
> **activity**

-------

Entry 3 - fullUrl = https://test.fhir.dk/Encounter/77bdc678-c508-43c3-bf39-4e2ced5ad70a

Resource Encounter:

> 

Profile: [KLGatewayLTTEncounter](StructureDefinition-klgateway-ltt-encounter.md)

**BasedOnCarePlan**:[CarePlan: status = active; intent = plan; period = 2025-05-14 09:12:05+0000 --> (ongoing)](Bundle-DeliveryReport-Josefine-1.md#CarePlan_857ea1d6-c212-4c89-a2f4-9e2bfa8c288d)**status**: completed**class**:ambulatory**type**:Forsamtale**subject**:[Anonymous Patient (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#0505149996 (use: official, ))](Bundle-DeliveryReport-Josefine-1.md#Patient_407ceb16-acb4-43ea-a4f5-d415c17faded)



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "DeliveryReport-Josefine-2",
  "meta" : {
    "profile" : [
      "http://fhir.kl.dk/ltt/StructureDefinition/klgateway-ltt-delivery-report"
    ]
  },
  "type" : "collection",
  "timestamp" : "2025-06-02T23:45:51Z",
  "entry" : [
    {
      "fullUrl" : "https://test.fhir.dk/Patient/407ceb16-acb4-43ea-a4f5-d415c17faded",
      "resource" : {
        "resourceType" : "Patient",
        "id" : "407ceb16-acb4-43ea-a4f5-d415c17faded",
        "meta" : {
          "profile" : [
            "http://fhir.kl.dk/ltt/StructureDefinition/klgateway-ltt-citizen"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_407ceb16-acb4-43ea-a4f5-d415c17faded\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient 407ceb16-acb4-43ea-a4f5-d415c17faded</b></p><a name=\"407ceb16-acb4-43ea-a4f5-d415c17faded\"> </a><a name=\"hc407ceb16-acb4-43ea-a4f5-d415c17faded\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-klgateway-ltt-citizen.html\">KLGatewayLTTCitizen</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Anonymous Patient (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#0505149996 (use: official, ))</p><hr/><table class=\"grid\"><tr><td style=\"background-color: #f3f5da\" title=\"Record is active\">Active:</td><td colspan=\"3\">true</td></tr><tr><td style=\"background-color: #f3f5da\" title=\"Patient Links\">Links:</td><td colspan=\"3\"><ul><li>Managing Organization: Identifier: <code>urn:oid:1.2.208.176.1.1</code>/451000016003 (use: official, )</li></ul></td></tr></table></div>"
        },
        "identifier" : [
          {
            "use" : "official",
            "system" : "urn:oid:1.2.208.176.1.2",
            "value" : "0505149996"
          }
        ],
        "active" : true,
        "managingOrganization" : {
          "identifier" : {
            "use" : "official",
            "system" : "urn:oid:1.2.208.176.1.1",
            "value" : "451000016003"
          }
        }
      }
    },
    {
      "fullUrl" : "https://test.fhir.dk/CarePlan/857ea1d6-c212-4c89-a2f4-9e2bfa8c288d",
      "resource" : {
        "resourceType" : "CarePlan",
        "id" : "857ea1d6-c212-4c89-a2f4-9e2bfa8c288d",
        "meta" : {
          "profile" : [
            "http://fhir.kl.dk/ltt/StructureDefinition/klgateway-ltt-care-plan"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"CarePlan_857ea1d6-c212-4c89-a2f4-9e2bfa8c288d\"> </a><p class=\"res-header-id\"><b>Generated Narrative: CarePlan 857ea1d6-c212-4c89-a2f4-9e2bfa8c288d</b></p><a name=\"857ea1d6-c212-4c89-a2f4-9e2bfa8c288d\"> </a><a name=\"hc857ea1d6-c212-4c89-a2f4-9e2bfa8c288d\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-klgateway-ltt-care-plan.html\">KLGatewayLTTCarePlan</a></p></div><p><b>status</b>: Active</p><p><b>intent</b>: Plan</p><p><b>subject</b>: <a href=\"Bundle-DeliveryReport-Josefine-1.html#Patient_407ceb16-acb4-43ea-a4f5-d415c17faded\">Anonymous Patient (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#0505149996 (use: official, ))</a></p><p><b>period</b>: 2025-05-14 09:12:05+0000 --&gt; (ongoing)</p><blockquote><p><b>activity</b></p><h3>Details</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Code</b></td><td><b>ReasonCode</b></td><td><b>Status</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://fhir.kl.dk/term/CodeSystem/CareSocialCodes 01302bcb-c7f3-42c4-8ded-68e33da064eb}\">Lettilgængelige tilbud til børn og unge i psykisk mistrivsel</span></td><td><span title=\"Codes:{http://fhir.kl.dk/term/CodeSystem/LTT bf4df811-805a-4309-8394-7d9ea31b8af7}\">Krop og mad</span></td><td>In Progress</td></tr></table></blockquote></div>"
        },
        "status" : "active",
        "intent" : "plan",
        "subject" : {
          "reference" : "Patient/407ceb16-acb4-43ea-a4f5-d415c17faded"
        },
        "period" : {
          "start" : "2025-05-14T09:12:05Z"
        },
        "activity" : [
          {
            "detail" : {
              "code" : {
                "coding" : [
                  {
                    "system" : "http://fhir.kl.dk/term/CodeSystem/CareSocialCodes",
                    "code" : "01302bcb-c7f3-42c4-8ded-68e33da064eb",
                    "display" : "Lettilgængelige tilbud til børn og unge i psykisk mistrivsel"
                  }
                ]
              },
              "reasonCode" : [
                {
                  "coding" : [
                    {
                      "system" : "http://fhir.kl.dk/term/CodeSystem/LTT",
                      "code" : "bf4df811-805a-4309-8394-7d9ea31b8af7",
                      "display" : "Krop og mad"
                    }
                  ]
                }
              ],
              "status" : "in-progress"
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "https://test.fhir.dk/Encounter/77bdc678-c508-43c3-bf39-4e2ced5ad70a",
      "resource" : {
        "resourceType" : "Encounter",
        "id" : "77bdc678-c508-43c3-bf39-4e2ced5ad70a",
        "meta" : {
          "profile" : [
            "http://fhir.kl.dk/ltt/StructureDefinition/klgateway-ltt-encounter"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Encounter_77bdc678-c508-43c3-bf39-4e2ced5ad70a\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Encounter 77bdc678-c508-43c3-bf39-4e2ced5ad70a</b></p><a name=\"77bdc678-c508-43c3-bf39-4e2ced5ad70a\"> </a><a name=\"hc77bdc678-c508-43c3-bf39-4e2ced5ad70a\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-klgateway-ltt-encounter.html\">KLGatewayLTTEncounter</a></p></div><p><b>BasedOnCarePlan</b>: <a href=\"Bundle-DeliveryReport-Josefine-1.html#CarePlan_857ea1d6-c212-4c89-a2f4-9e2bfa8c288d\">CarePlan: status = active; intent = plan; period = 2025-05-14 09:12:05+0000 --&gt; (ongoing)</a></p><p><b>status</b>: Finished</p><p><b>class</b>: <a href=\"http://terminology.hl7.org/6.5.0/CodeSystem-v3-ActCode.html#v3-ActCode-AMB\">ActCode AMB</a>: ambulatory</p><p><b>type</b>: <span title=\"Codes:{http://fhir.kl.dk/term/CodeSystem/LTT e2eee938-a58c-42d0-a514-dc91779b1243}\">Forsamtale</span></p><p><b>subject</b>: <a href=\"Bundle-DeliveryReport-Josefine-1.html#Patient_407ceb16-acb4-43ea-a4f5-d415c17faded\">Anonymous Patient (no stated gender), DoB Unknown ( urn:oid:1.2.208.176.1.2#0505149996 (use: official, ))</a></p><p><b>period</b>: 2025-06-02 13:06:35+0000 --&gt; (ongoing)</p></div>"
        },
        "extension" : [
          {
            "url" : "http://fhir.kl.dk/ltt/StructureDefinition/klgateway-ltt-encounter-based-on-care-plan",
            "valueReference" : {
              "reference" : "CarePlan/857ea1d6-c212-4c89-a2f4-9e2bfa8c288d"
            }
          }
        ],
        "status" : "finished",
        "class" : {
          "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
          "code" : "AMB",
          "display" : "ambulatory"
        },
        "type" : [
          {
            "coding" : [
              {
                "system" : "http://fhir.kl.dk/term/CodeSystem/LTT",
                "code" : "e2eee938-a58c-42d0-a514-dc91779b1243",
                "display" : "Forsamtale"
              }
            ]
          }
        ],
        "subject" : {
          "reference" : "Patient/407ceb16-acb4-43ea-a4f5-d415c17faded"
        },
        "period" : {
          "start" : "2025-06-02T13:06:35Z"
        }
      }
    }
  ]
}

```

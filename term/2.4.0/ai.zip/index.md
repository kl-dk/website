# Home - KL Terminologi v2.4.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://fhir.kl.dk/term/ImplementationGuide/kl.dk.fhir.term | *Version*:2.4.0 |
| Active as of 2026-04-21 | *Computable Name*:KLTerm |

# kl.dk.fhir.term

This implementation guide contains CodeSystems and ValueSets owned by Local Government Denmark.

### Dependencies



### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (kl.dk.fhir.term.r4)](package.r4.tgz) and [R4B (kl.dk.fhir.term.r4b)](package.r4b.tgz) are available.

### Global Profiles

*There are no Global profiles defined*

### IP Statements

This publication includes IP covered under the following statements.

* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [KLComplicationCodesSCT](ValueSet-KLComplicationCodesSCT.md), [KLEvaluationTypeCodesSCT](ValueSet-KLEvaluationTypeCodesSCT.md) and [KLObservationCodes](ValueSet-KLObservationCodes.md)



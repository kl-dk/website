# CareSocialCodes - KL Terminologi v2.4.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CareSocialCodes**

## CodeSystem: CareSocialCodes 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.kl.dk/term/CodeSystem/CareSocialCodes | *Version*:2.4.0 |
| Active as of 2026-04-21 | *Computable Name*:CareSocialCodes |

 
Administrative/technical codes in Local Govenment Denmark (KL), associated with common use cases across areas or kl-core 

 This Code system is referenced in the content logical definition of the following value sets: 

* [CancellationTypes](ValueSet-CancellationTypes.md)
* [KLCarePlanCategoryCodes](ValueSet-KLCarePlanCategoryCodes.md)
* [KLConsentToLiasing](ValueSet-KLConsentToLiasing.md)
* [KLEncounterTypes](ValueSet-KLEncounterTypes.md)
* [KLEvaluationTypeCodes](ValueSet-KLEvaluationTypeCodes.md)
* [KLGoalTypeCodes](ValueSet-KLGoalTypeCodes.md)
* [KLInformationGatheringTypeCodes](ValueSet-KLInformationGatheringTypeCodes.md)
* [KLMatterOfInterestInformerFFB](ValueSet-KLMatterOfInterestInformerFFB.md)
* [KLServicesTypes](ValueSet-KLServicesTypes.md)
* [KLTargetMeasureCodes](ValueSet-KLTargetMeasureCodes.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "CareSocialCodes",
  "url" : "http://fhir.kl.dk/term/CodeSystem/CareSocialCodes",
  "version" : "2.4.0",
  "name" : "CareSocialCodes",
  "title" : "CareSocialCodes",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-04-21T22:00:20+02:00",
  "publisher" : "Kommunernes Landsforening",
  "contact" : [{
    "name" : "Kommunernes Landsforening",
    "telecom" : [{
      "system" : "url",
      "value" : "http://kl.dk"
    }]
  }],
  "description" : "Administrative/technical codes in Local Govenment Denmark (KL), associated with common use cases across areas or kl-core",
  "caseSensitive" : true,
  "hierarchyMeaning" : "is-a",
  "content" : "complete",
  "concept" : [{
    "code" : "10deb210-e7e1-4d56-9531-b9ff2102126e",
    "display" : "Planlagt indsatsforløb",
    "definition" : "Planlagt indsatsforløb",
    "concept" : [{
      "code" : "01302bcb-c7f3-42c4-8ded-68e33da064eb",
      "display" : "Lettilgængelige tilbud til børn og unge i psykisk mistrivsel",
      "definition" : "Forløbskode for lettilgængelige tilbud til børn og unge i psykisk mistrivsel."
    },
    {
      "code" : "e459386d-1474-4c31-89c5-c8bc7a25e3d4",
      "display" : "Social indsats",
      "definition" : "Det planlagte indsatsforløb er en social indsats, som defineret af FFB, med tilhørende ydelser, målgruppe og tilbud"
    },
    {
      "code" : "4fd6c23a-6ff3-4251-ac37-3ca095027b5b",
      "display" : "Kommunal Sundhedsfremme og forebyggelse",
      "definition" : "Det planlagte indsatsforløb vedrører sundhedsfremme og forebyggelse efter §119.",
      "concept" : [{
        "code" : "5c160c02-e858-4c1f-925a-71ed64844749",
        "display" : "Interventionsforløb efter §119",
        "definition" : "Et planlagt §119 indsatsforløb, som udelukkende indeholder interventioner, og som leveres samlet. Med interventioner menes indsatser, der søger at forbedre borgers tilstand. For §119 kunne et interventionsforløb fx være et KOL-træningshold der indeholder indsatserne fysisk træning og funktionstræning."
      },
      {
        "code" : "9791e55a-656f-47eb-8fd5-c4a06b0a4662",
        "display" : "Opfølgningsforløb efter §119",
        "definition" : "Planlagt indsatsforløb der består af opfølgningsindsatser. Anvendes hvis der i forvejen planlægges opfølgning ved flere forskellige lejligheder fx efter 2,4 og 6 måneder."
      }]
    },
    {
      "code" : "ddd2f670-5ec7-4f9c-9a2c-aee25cb133bf",
      "display" : "Kommunal genoptræning efter sygehusophold",
      "definition" : "Det planlagte indsatsforløb er genoptræning efter sundhedslovens §140.",
      "concept" : [{
        "code" : "4863001e-14c7-4be8-a2da-e4f21a4b6ac4",
        "display" : "Opfølgningsforløb efter §140",
        "definition" : "Planlagt indsatsforløb efter §140 der består af opfølgningsindsatser. Anvendes hvis der i forvejen planlægges opfølgning ved flere forskellige lejligheder fx efter 2,4 og 6 måneder."
      },
      {
        "code" : "f15b2663-94d9-4d0c-a5de-d8bd8e1e4ebb",
        "display" : "Interventionsforløb efter §140",
        "definition" : "Et planlagt §140 indsatsforløb, som udelukkende indeholder interventioner, og som leveres samlet. Med interventioner menes indsatser, der søger at forbedre borgers tilstand. For §140 kunne et interventionsforløb fx være et Knæ-genoptræningshold der indeholder indsatserne fysisk træning, funktionstræning og vejledning og undervisning."
      }]
    }]
  },
  {
    "code" : "11266a8f-5795-42ab-88ec-4fe5c6c28e80",
    "display" : "Målfokus",
    "definition" : "Målfokus",
    "concept" : [{
      "code" : "66959f77-6e2a-4574-8423-3ff097f8b9fa",
      "display" : "funktionsevneniveau",
      "definition" : "målet udtrykkes i form af et funktionsevneniveau, som kan være et FFB funktionsevneniveau eller FSIII tilstandsniveau"
    },
    {
      "code" : "90c48f03-f194-4b2f-ad7d-6cba1069ae48",
      "display" : "måltype",
      "definition" : "målet udtrykkes i form af en måltype, måltypen er den forventede ændring i tilstanden givet indsatsen"
    }]
  },
  {
    "code" : "25303acd-dcaf-4a8e-a8a3-3961a43858aa",
    "display" : "kontaktaktivitet",
    "definition" : "aktivitet der foretages ved kommunal kontakt.",
    "concept" : [{
      "code" : "829ac647-c7fc-4964-836b-f708d886e0e3",
      "display" : "oplysning",
      "definition" : "oplysning er foretaget ved kontakt"
    },
    {
      "code" : "9269c9a2-8220-447b-a127-811275b41062",
      "display" : "vurdering/bevilling",
      "definition" : "vurdering og/eller bevilling er foretaget ved kontakt"
    },
    {
      "code" : "9f03dfbb-7a97-45a5-94db-d4c3501714a9",
      "display" : "opfølgning",
      "definition" : "opfølgning foretaget ved kontakt"
    },
    {
      "code" : "bb6fc544-7f4f-4b50-8868-1431e0df2381",
      "display" : "observation",
      "definition" : "observation foretaget ved kontakt"
    },
    {
      "code" : "4530b499-d74b-4d2e-9df9-247047fb231d",
      "display" : "udførelse af indsats",
      "definition" : "Indsats udført ved kontakt",
      "concept" : [{
        "code" : "15775b0a-7ec6-469e-9d3c-a81fbc9a1b45",
        "display" : "udførelse af akutindsats",
        "definition" : "Akutindsats, bevilget af læge eller akutteam, udført ved kontakt"
      },
      {
        "code" : "784275f1-6822-4a88-b361-d958007d5253",
        "display" : "udførelse af planlagt indsats",
        "definition" : "Planlagt indsats udført ved kontakt"
      },
      {
        "code" : "c03b426a-4348-407f-b343-f4baa9759c72",
        "display" : "udførelse af ikke-bevilget indsats",
        "definition" : "Indsats, der ikke i forvejen var bevilget, udført ved kontakt"
      }]
    }]
  },
  {
    "code" : "253bbdc0-c4ca-4e77-9d3e-3a9e51281636",
    "display" : "Mål/formål",
    "definition" : "Mål/formål",
    "concept" : [{
      "code" : "0bb3daef-538d-45dc-b444-abdbcb63f6bc",
      "display" : "FFB indsatsmål",
      "definition" : "Indsatsmål i FFB - er de konkrete faglige mål der arbejdes med, og som er knyttet til tilstande og opfølgninger"
    },
    {
      "code" : "416fe27d-3ccf-4390-8742-8b52a9d8dc78",
      "display" : "FFB borgers mål og ønsker",
      "definition" : "Borgers mål og ønsker som specificeret af FFB. Det er overordnet og er som udtrykt af borger"
    },
    {
      "code" : "424827b1-23aa-4848-962b-56ee47def560",
      "display" : "Indsatsformål",
      "definition" : "Det overordnede formål med hele indsatsen (Defineret af FFB men bruges også for FSIII)"
    },
    {
      "code" : "6746d4af-145a-4bfd-a672-05c0cf11b53b",
      "display" : "FFB delmål",
      "definition" : "Delmål i FFB, ligger under indsatsmål, og er som udtrykt af udfører"
    },
    {
      "code" : "ca552020-6ed1-4cdc-b0d4-32697f1f27ad",
      "display" : "FSIII tilstandsmål",
      "definition" : "Tilstandsmål som defineret af FSIII - ofte i form af en forventet tilstand"
    },
    {
      "code" : "ffb9886b-d04e-46b1-9165-a400f91f822b",
      "display" : "Borgers ønsker og mål",
      "definition" : "Borgers ønsker og mål"
    }]
  },
  {
    "code" : "2c059407-fed5-4852-92d8-6bb5ad63d7bb",
    "display" : "Begrundelse for indsatsophør",
    "definition" : "Begrundelse for, at kommunale indsatser ophører",
    "concept" : [{
      "code" : "4bbf6d6a-a1c6-41c2-b8c1-7352b7378adf",
      "display" : "Ikke yderligere behov (borger-vurderet)",
      "definition" : "Borger vurderer, at han/hun ikke har yderligere behov og afslutter derfor før tid"
    },
    {
      "code" : "82e99421-31da-4915-96ed-168ccfa1d20c",
      "display" : "Hændelse medfører ophør",
      "definition" : "Hændelse, som ikke er et aktivt fravalg eller en behovsvurdering medfører ophør. Det kan fx være en længere hospitalsindlæggelse, eller at borger flytter."
    },
    {
      "code" : "a63b6aa6-7d56-4e67-a5b3-d73f6d262af5",
      "display" : "Ikke yderligere behov (fagperson-vurderet)",
      "definition" : "Fagperson vurderer, at borger ikke har yderligere behov og afslutter derfor før tid"
    },
    {
      "code" : "ef491570-7884-4acd-bcf7-43d6b2c64762",
      "display" : "Borger har ikke henvendt sig eller er udeblevet",
      "definition" : "Borger har ikke henvendt sig eller er udeblevet"
    },
    {
      "code" : "3a5a72b7-addf-4857-b80c-04e4246e3072",
      "display" : "Aktivt fravalg",
      "definition" : "Borger har behov, men har foretaget et aktivt fravalg",
      "concept" : [{
        "code" : "0cd5734d-b663-47c6-a3da-6b14a937d144",
        "display" : "Aktivt fravalg pga. anden sygdom",
        "definition" : "Borger har behov, men har foretaget et aktivt fravalg pga. anden sygdom"
      },
      {
        "code" : "8371b769-4bfb-4ac8-b130-d91c54784a56",
        "display" : "Aktivt fravalg pga. logistik ifm. transport",
        "definition" : "Borger har behov, men har foretaget et aktivt fravalg pga. den logistiske udfordring det er mht. transport, at nå frem til det sted indsatsen tilbydes"
      },
      {
        "code" : "a3f2bd01-078b-486e-81be-797d192ad7bd",
        "display" : "Aktivt fravalg pga. anden træning",
        "definition" : "Borger har behov, men har foretaget et aktivt fravalg fordi han/hun er påbegyndt træning i andet regi fx fitnesscenter"
      },
      {
        "code" : "f8436c2e-af1c-44fe-939d-473b518dd01d",
        "display" : "Aktivt fravalg pga. økonomi ifm. transport",
        "definition" : "Borger har behov, men har foretaget et aktivt fravalg pga. den omkostning der er forbundet med transport til det sted indsatsen tilbydes"
      }]
    }]
  },
  {
    "code" : "3762dd32-4123-43a8-815d-ec40d3697652",
    "display" : "indforståelse ifm henvendelse",
    "definition" : "indforståelse ifm henvendelse",
    "concept" : [{
      "code" : "54aeeba6-6aa2-4165-a5a8-bbd6f2f3b1eb",
      "display" : "ikke indforstået",
      "definition" : "Borger ikke indforstået med henvendelse"
    },
    {
      "code" : "e67035da-9179-466b-99ad-ea86835d38c9",
      "display" : "indforstået",
      "definition" : "Borger indforstået med henvendelse"
    }]
  },
  {
    "code" : "3f79cee2-b148-4f2c-9cbd-387820e74685",
    "display" : "Leveringstype",
    "definition" : "Om der leveres individuelt eller gruppebaseret",
    "concept" : [{
      "code" : "284857a4-5e91-499a-a001-64d7f0b7038a",
      "display" : "Digital levering af indsats",
      "definition" : "En applikation med fokus på adfærdsændring eller træning leverer indsatsen."
    },
    {
      "code" : "2865f123-15a7-4a36-a514-32ea37c400ca",
      "display" : "Gruppebaseret indsats",
      "definition" : "Indsats leveres af en medarbejder, der interagerer med en gruppe som borgeren er del af."
    },
    {
      "code" : "34cdd6ab-3da9-49e8-84dc-1cbf683d4fcf",
      "display" : "Robot leverer indsats",
      "definition" : "En robot leverer indsatsen.\n\nEksempler: Robotstøvsugning"
    },
    {
      "code" : "8d12d74c-17da-47a7-a4fe-e69dbaec0a8c",
      "display" : "Individuel indsats",
      "definition" : "Indsats leveres af en medarbejder i en-til-en interaktion."
    }]
  },
  {
    "code" : "6b29554d-0261-4ec4-bb16-022d81c7dfb7",
    "display" : "Type genoptræningsplan",
    "definition" : "Type genoptræningsplan",
    "concept" : [{
      "code" : "0c8e2bfc-1350-45d1-90da-c07e2645d073",
      "display" : "Specialiseret",
      "definition" : "Midlertidig kopi af MedComs kode for genoptræning på specialieret niveau, som specificeret af den gode genoptræningsplan, https://svn.medcom.dk/svn/releases/Standarder/National%20Sygehus-Kommunesamarbejde/GGOP/Dokumentation/GGOP.pdf"
    },
    {
      "code" : "83c89857-8fb8-4163-97b1-eb1a56345c29",
      "display" : "Rehabilitering",
      "definition" : "Midlertidig kopi af MedComs kode for rehabilitering på specialiseret niveau, som specificeret af den gode genoptræningsplan, https://svn.medcom.dk/svn/releases/Standarder/National%20Sygehus-Kommunesamarbejde/GGOP/Dokumentation/GGOP.pdf"
    },
    {
      "code" : "8b962281-2ab6-4b10-9c91-4bac592d6d49",
      "display" : "Basal",
      "definition" : "Almen genoptræning på basalt niveau"
    },
    {
      "code" : "b679c454-2da2-46dd-9425-0e52d4aa2bf3",
      "display" : "Avanceret",
      "definition" : "Almen genoptræning på avanceret niveau"
    },
    {
      "code" : "ffd81f78-352e-4589-a195-5350dd1df2a4",
      "display" : "Almen",
      "definition" : "Midlertidig kopi af MedComs kode for genoptræning på alment niveau, som specificeret af den gode genoptræningsplan, https://svn.medcom.dk/svn/releases/Standarder/National%20Sygehus-Kommunesamarbejde/GGOP/Dokumentation/GGOP.pdf"
    }]
  },
  {
    "code" : "7b41185e-eeb4-437d-8120-5d51bbd27a79",
    "display" : "Indsats/ydelses-anmodning",
    "definition" : "Indsats/ydelses-anmodning",
    "concept" : [{
      "code" : "490ab7be-ddb1-4a54-baf1-009fe6e8a83b",
      "display" : "Kommunal sygepleje",
      "definition" : "Der anmodes om kommunal sygepleje."
    },
    {
      "code" : "4a297733-4d66-4726-a933-590d55cf91e0",
      "display" : "Social indsats",
      "definition" : "Der anmodes om en social indsats"
    },
    {
      "code" : "7fc66c15-0cb3-4c89-9e18-f3a01e6a6592",
      "display" : "Kommunal genoptræning efter sygehusophold",
      "definition" : "Der anmodes om kommunal genoptræning efter sygehusophold efter SUL §140."
    },
    {
      "code" : "a71921ea-fe83-441d-933b-cc21d0b3c8c3",
      "display" : "Kommunal Sundhedsfremme og forebyggelse",
      "definition" : "Der anmodes om kommunal sundhedsfremme og forebyggelse efter SUL §119."
    },
    {
      "code" : "ad865929-7363-4b2d-a271-01993181fbaf",
      "display" : "Kommunal pleje og omsorg",
      "definition" : "Der anmodes om kommunal pleje og omsorg fx hjemmepleje til ældre borger."
    },
    {
      "code" : "d267ac44-8d7f-43e9-8535-ab3da350649f",
      "display" : "Kommunalt hjælpemiddelområde",
      "definition" : "Der anmodes om hjælpemidler og lignende, der ligger indenfor det kommunale hjælpemiddelområde dvs § 112, § 113, § 114, § 116 i Serviceloven."
    }]
  },
  {
    "code" : "880028ec-5f16-4242-ba53-57a902094d5b",
    "display" : "Deltagere i kontakt",
    "definition" : "Deltagere i kontakt",
    "concept" : [{
      "code" : "ca228a58-bd0e-4b0e-81ce-3866adc26535",
      "display" : "Barn/ung deltager",
      "definition" : "Behandler og barn/ung i målgruppen (5-17år) og evt. forældre, værger el.lign. er til stede. Barnet/den unge er genstand for journaloptagelsen."
    },
    {
      "code" : "d3578249-10df-4051-851d-3986b1570bee",
      "display" : "Omsorgsperson uden barn/ung",
      "definition" : "Behandling hvor kun behandler og forældre, værger el.lign. til barn/ung er til stede. Barnet/den unge er genstand for journalen."
    }]
  },
  {
    "code" : "940f37e6-8a3d-483b-adac-be8af3268a5b",
    "display" : "oplysningsaktivitet",
    "definition" : "oplysningsaktivitet",
    "concept" : [{
      "code" : "0f0f223c-abe3-4720-aab8-c257679a0a4e",
      "display" : "terapeutfaglig udredning, FSIII",
      "definition" : "udførelse af terapeutfaglig udredning jævnfør FSIII"
    },
    {
      "code" : "47fd1468-89da-4803-9d7a-ecc039a30d92",
      "display" : "sygeplejefaglig udredning, FSIII",
      "definition" : "udførelse af sygeplejefaglig udredning jævnfør FSIII"
    },
    {
      "code" : "95e787e0-5490-437d-ae4c-f3736644242f",
      "display" : "afklarende samtale §119, FSIII",
      "definition" : "udførelse af afklarende samtale vedr. sundhedsfremme og forebyggelse jævnfør FSIII"
    },
    {
      "code" : "e5a73b0e-a5d2-430e-931f-6156306ab00f",
      "display" : "funktionsevnevurdering hjemmepleje, FSIII",
      "definition" : "udførelse af funktionsevnevurdering i hjemmeplejen jævnfør FSIII"
    },
    {
      "code" : "f8ebd11a-04f3-4aa0-9786-406e8896c84d",
      "display" : "socialfaglig udredning, VUM/FFB",
      "definition" : "udførelse af socialfaglig udredning som specificeret af VUM og FFB"
    }]
  },
  {
    "code" : "95ec4535-8fe8-4296-867c-35de421794cf",
    "display" : "evaluering",
    "definition" : "evaluering",
    "concept" : [{
      "code" : "053a301d-1bb8-4cc4-b781-87825ecf0ef8",
      "display" : "FFB vurdering af borgers situation",
      "definition" : "Vurdering der sammenholder oplysninger fra udredning mhp en samlet faglig analyse og konklusion."
    },
    {
      "code" : "3f7a8ca0-afca-4b0d-8773-a99b5f2f8aaf",
      "display" : "VUM Borgerens perspektiv på indsatsen",
      "definition" : "VUM Borgerens perspektiv på indsatsen"
    },
    {
      "code" : "effe55c7-572c-4a99-8fb4-2a9dda2f6572",
      "display" : "FFB støttebehovsvurdering",
      "definition" : "Angiver, hvor stort et behov borgeren har for hjælp og støtte."
    },
    {
      "code" : "f52887de-023f-4193-b6b0-4b0a37b1cffc",
      "display" : "VUM Borgerens ressourcer i forhold til indsatsen",
      "definition" : "VUM Borgerens ressourcer i forhold til indsatsen"
    }]
  },
  {
    "code" : "b5731132-f6b9-4a47-995d-681d2b755d4f",
    "display" : "Kilde",
    "definition" : "Person der er kilde til oplysning eller vurdering",
    "concept" : [{
      "code" : "12428e48-7df8-441f-9a89-d92bb7874066",
      "display" : "Borger støttet af medarbejder",
      "definition" : "Borger fik hjælp af en medarbejder til at komme med oplysninger eller vurderinger. Fx ældre borger der får hjælp til at udfylde WHO5 spørgeskema."
    },
    {
      "code" : "166d2437-4e47-4a52-bd94-cdbe91086ca6",
      "display" : "Pårørende alene",
      "definition" : "Pårørende er alene, uden input fra borger, kilde til oplysninger eller vuderderinger. Fx WHO 5 spørgeskema for svækket ældre borger udfyldt af datter."
    },
    {
      "code" : "25b4e705-2e9a-47a2-b11a-c829316b9d3a",
      "display" : "Borger",
      "definition" : "Borger er kilde til oplysning eller vurdering"
    },
    {
      "code" : "329774f9-7700-47cf-9c00-63765d9e8078",
      "display" : "Medarbejder og pårørende alene",
      "definition" : "En medarbejder og pårørende er sammen, men uden input fra borger, kilde til oplysning eller vurdering. Fx PUF spørgeskema i sundhedsplejen."
    },
    {
      "code" : "8fe80acb-2c2a-4f10-b2b8-ddb77d2f69dc",
      "display" : "Medarbejder alene",
      "definition" : "Medarbejderen er alene kilde til oplysning eller vurdering. Fx AIMS skema i sundhedsplejen."
    },
    {
      "code" : "b66dc78a-a673-43fc-8ac0-1e859ba626e0",
      "display" : "Borger støttet af pårørende",
      "definition" : "Borger fik hjælp af en pårørende til at komme med oplysninger eller vurderinger. Fx ældre borger der får hjælp til at udfylde WHO5 spørgeskema."
    },
    {
      "code" : "f6ea2920-7dde-491e-a489-6b99a3904069",
      "display" : "Sagsbehandler",
      "definition" : "Sagsbehandler er kilde til oplysning eller vurdering"
    },
    {
      "code" : "63338442-7b2e-405b-acc0-142361ef19f1",
      "display" : "Andre",
      "definition" : "Andre end borger og sagsbehandler er kilde til oplysning eller vurdering. Fx læge, pårørende og udfører. Denne definition af andre, bruges kun på voksensocialområdet.",
      "concept" : [{
        "code" : "f00a6844-1005-401d-965d-1c5859df7beb",
        "display" : "Udfører",
        "definition" : "Udfører er kilde til oplysning eller vurdering"
      }]
    }]
  },
  {
    "code" : "bb233864-6d4c-4ab4-a4a3-567e61b3dfb0",
    "display" : "Begrundelse for manglende aktivitet",
    "definition" : "Begrundelse for manglende aktivitet",
    "concept" : [{
      "code" : "3796fa11-305f-47d6-b164-45b05489afb2",
      "display" : "Frit valg",
      "definition" : "Borger er overgået til frit valg af service. Fx frit valg af privat genoptræning som borger har ret til, hvis kommunen ikke kan levere inden 7 dage."
    },
    {
      "code" : "46a6bc1f-bfe8-4390-a71f-44ad4a384b9d",
      "display" : "Frit valg afslået",
      "definition" : "Borgeren er tilbudt frit valg af leverandør af service, men vil hellere vente."
    },
    {
      "code" : "8ac7be88-5d16-4dbd-a61a-ab02673f4b34",
      "display" : "Fejl",
      "definition" : "Fejlafsendt anmodning. Fx fejlafsendt genoptræningsplan."
    },
    {
      "code" : "a8632e22-bf0c-4f5a-92a7-70977ba104d5",
      "display" : "Udskudt",
      "definition" : "Udskudt opstart påkrævet fordi det er specificeret sådan i den anmodning kommunen har modtaget. Fx kan udskudt opstart af træning fordi sår skal ophele være beskrives i en genoptræningsplan (GGOP)."
    },
    {
      "code" : "f64b8f5e-8ced-4a8b-ab73-8994fb524915",
      "display" : "Anden kommmune",
      "definition" : "Overgivet til anden kommune, på borgers anmodning"
    }]
  },
  {
    "code" : "bf469e95-f9e3-45c7-bf15-ab7e8a85236f",
    "display" : "Kontaktklasse",
    "definition" : "Type af kontakt. Beskriver leveringsmetode.",
    "concept" : [{
      "code" : "124be95d-6924-4609-9d2a-e7c73ae3ab3d",
      "display" : "Skærmbesøg",
      "definition" : "Kontakten er foregået via skærm med mulighed for tændt kamera, så parterne har haft mulighed for at interagere ansigt til ansigt, og fremvise ting."
    },
    {
      "code" : "1b55a4b0-1156-4f58-b2df-b5c6014d9048",
      "display" : "Telefonisk",
      "definition" : "Kontakten er foregået per telefon."
    }]
  }]
}

```

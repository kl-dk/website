# KLIndsatserFSIII - KL Terminologi v2.4.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **KLIndsatserFSIII**

## ValueSet: KLIndsatserFSIII 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.kl.dk/term/ValueSet/KLInterventionsFSIII | *Version*:2.4.0 |
| Active as of 2026-04-21 | *Computable Name*:KLInterventionsFSIII |

 
Interventions as described by FSIII 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "KLInterventionsFSIII",
  "url" : "http://fhir.kl.dk/term/ValueSet/KLInterventionsFSIII",
  "version" : "2.4.0",
  "name" : "KLInterventionsFSIII",
  "title" : "KLIndsatserFSIII",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-04-21T22:00:20+02:00",
  "publisher" : "Kommunernes Landsforening",
  "contact" : [{
    "name" : "Kommunernes Landsforening",
    "telecom" : [{
      "system" : "url",
      "value" : "http://kl.dk"
    }]
  }],
  "description" : "Interventions as described by FSIII",
  "compose" : {
    "include" : [{
      "valueSet" : ["http://fhir.kl.dk/term/ValueSet/KLNursingInterventionsFSIII"]
    },
    {
      "valueSet" : ["http://fhir.kl.dk/term/ValueSet/KLHomeCareInterventionsFSIII"]
    },
    {
      "valueSet" : ["http://fhir.kl.dk/term/ValueSet/KLTrainingInterventionsFSIII"]
    },
    {
      "valueSet" : ["http://fhir.kl.dk/term/ValueSet/KLPreventionInterventionsFSIII"]
    }]
  }
}

```

# KLTilstandFFKoderFFB - KL Terminologi v2.4.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **KLTilstandFFKoderFFB**

## ValueSet: KLTilstandFFKoderFFB 

| | |
| :--- | :--- |
| *Official URL*:http://fhir.kl.dk/term/ValueSet/KLConditionFFCodesFFB | *Version*:2.4.0 |
| Active as of 2026-04-21 | *Computable Name*:KLConditionFFCodesFFB |

 
Danish municipality FFB condition codes for body functions and structures 

 **References** 

* Included into [KLConditionCodesFFB](ValueSet-KLConditionCodesFFB.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "KLConditionFFCodesFFB",
  "url" : "http://fhir.kl.dk/term/ValueSet/KLConditionFFCodesFFB",
  "version" : "2.4.0",
  "name" : "KLConditionFFCodesFFB",
  "title" : "KLTilstandFFKoderFFB",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-04-21T22:08:40+02:00",
  "publisher" : "Kommunernes Landsforening",
  "contact" : [{
    "name" : "Kommunernes Landsforening",
    "telecom" : [{
      "system" : "url",
      "value" : "http://kl.dk"
    }]
  }],
  "description" : "Danish municipality FFB condition codes for body functions and structures",
  "compose" : {
    "include" : [{
      "system" : "urn:oid:1.2.208.176.2.22",
      "filter" : [{
        "property" : "concept",
        "op" : "descendent-of",
        "value" : "a134c31d-d316-46d4-935e-e500874dbbe1"
      }]
    },
    {
      "system" : "urn:oid:1.2.208.176.2.22",
      "filter" : [{
        "property" : "concept",
        "op" : "descendent-of",
        "value" : "25c5c614-305f-46cd-9891-55d564fc30cf"
      }]
    },
    {
      "system" : "urn:oid:1.2.208.176.2.22",
      "filter" : [{
        "property" : "concept",
        "op" : "descendent-of",
        "value" : "e1836145-0c20-4e20-971e-d62dfe4ea1a0"
      }]
    },
    {
      "system" : "urn:oid:1.2.208.176.2.22",
      "filter" : [{
        "property" : "concept",
        "op" : "descendent-of",
        "value" : "4fb78b88-d3af-4cfb-84d7-f06daf423317"
      }]
    }]
  }
}

```

# FFB - KL Terminologi v2.4.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **FFB**

## CodeSystem: FFB 

| | |
| :--- | :--- |
| *Official URL*:urn:oid:1.2.208.176.2.22 | *Version*:2.4.0 |
| Active as of 2026-04-21 | *Computable Name*:FFB |
| *Other Identifiers:*urn:oid#urn:oid:1.2.208.176.2.22 | |

 
Codes from FFB 

 This Code system is referenced in the content logical definition of the following value sets: 

* [KLChangeValueCodesFFB](ValueSet-KLChangeValueCodesFFB.md)
* [KLConditionADCodesFFB](ValueSet-KLConditionADCodesFFB.md)
* [KLConditionFFCodesFFB](ValueSet-KLConditionFFCodesFFB.md)
* [KLConditionOCodesFFB](ValueSet-KLConditionOCodesFFB.md)
* [KLFollowUpCodesFFB](ValueSet-KLFollowUpCodesFFB.md)
* [KLInterventionsFFB](ValueSet-KLInterventionsFFB.md)
* [KLMatterOfInterestValues](ValueSet-KLMatterOfInterestValues.md)
* [KLNeedsAssessmentCodesFFB](ValueSet-KLNeedsAssessmentCodesFFB.md)
* [KLServiceCodesFFB](ValueSet-KLServiceCodesFFB.md)
* [KLSeveritiesFFB](ValueSet-KLSeveritiesFFB.md)
* [KLTargetGroupsFFB](ValueSet-KLTargetGroupsFFB.md)
* [KLThemesFFB](ValueSet-KLThemesFFB.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "FFB",
  "url" : "urn:oid:1.2.208.176.2.22",
  "identifier" : [{
    "system" : "urn:oid",
    "value" : "urn:oid:1.2.208.176.2.22"
  }],
  "version" : "2.4.0",
  "name" : "FFB",
  "title" : "FFB",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-04-21T22:08:40+02:00",
  "publisher" : "Kommunernes Landsforening",
  "contact" : [{
    "name" : "Kommunernes Landsforening",
    "telecom" : [{
      "system" : "url",
      "value" : "http://kl.dk"
    }]
  }],
  "description" : "Codes from FFB",
  "caseSensitive" : true,
  "hierarchyMeaning" : "is-a",
  "content" : "complete",
  "concept" : [{
    "code" : "67b4ac73-dedf-4337-ad56-476b0a55ab03",
    "display" : "Social indsats",
    "definition" : "En social indsats, er en indsats, der består af en eller flere ydelser, som leveres til en eller flere borgere af et eller flere tilbud. En social indsats skal forebygge eller tilgodese behov, som følger af en nedsat funktionsevne. Indsatsen gives med henblik på at fremme den enkeltes mulighed for at klare sig selv eller at lette den daglige tilværelse eller forbedre livskvaliteten. I generelle vendinger er det tale om en social indsats, når 'nogen' leverer 'noget' til 'en modtager' med det beskrevne formål. Mere konkret vil en social indsats bestå af en eller flere specifikke ydelser, som typisk leveres til én borger af ét tilbud. Det kan fx være når et ambulant behandlingstilbud til voksne leverer misbrugsbehandling til en stofmisbruger eller når et socialpædagogisk opholdssted leverer socialpædagogisk behandling til et barn. Der vil typisk være en eller flere bestemte faglige tilgange til leveringen af den sociale indsats, der kan leveres efter en eller flere metoder. En social indsats vil almindeligvis...",
    "concept" : [{
      "code" : "af7624f8-affd-4a7e-8754-b1b1dd9d8def",
      "display" : "Ydelse",
      "definition" : "En ydelse er en tjeneste, genstand eller et beløb, der gives eller modtages. En ydelse på socialområdet kan i visse tilfælde også bestå af en sanktion, som fx forældrepålæg.",
      "concept" : [{
        "code" : "72a2a2d4-5a83-4093-ba1c-7f759c132801",
        "display" : "Afklaring",
        "definition" : "Afklaring er en ydelse, der har til formål at afdække en borgers situation.",
        "concept" : [{
          "code" : "35b593cf-724f-4058-9f31-fe1b3e8df124",
          "display" : "Pædagogisk udredning",
          "definition" : "Pædagogisk udredning er en aktivitet, hvor en leverandør afdækker en borgers funktionsevne i relation til daglige aktiviteter. Et centralt aspekt i afdækningen af funktionsevnen er borgerens mestringsevne, som har betydning for, hvordan man begriber, håndterer og handler i forskellige situationer. Visitationsparagraf: Serviceloven § 85."
        }]
      },
      {
        "code" : "a1eaa022-9e5c-493c-83d3-7cc40b9df9e9",
        "display" : "Ophold",
        "definition" : "Ophold er en ydelse, der har til formål at huse en borger. Ophold leveres typisk af en type af botilbud. Ophold er i langt de fleste tilfælde én ud af flere ydelser, der leveres til borgeren af tilbuddet. Derfor betragtes ophold stort set altid som et tillæg til disse andre ydelser. Det primære fokus for den sociale indsats er ofte disse andre ydelser, der leveres i forbindelse med opholdet. Der kan være egenbetaling for borgerens ophold. Det kan fx omfatte betaling for husleje, el, varme, vand, kost og vask.",
        "concept" : [{
          "code" : "5af56051-8413-4115-aaa2-83a0767e1137",
          "display" : "Længerevarende ophold",
          "definition" : "Længerevarende ophold er en ydelse, der har til formål at huse en borger, og som er tilkendt for en ikke-midlertidig periode. Ophold leveres typisk af en type af botilbud. Ophold er i langt de fleste tilfælde én ud af flere ydelser, der leveres til borgeren af tilbuddet. Derfor betragtes ophold stort set altid som et tillæg til disse andre ydelser. Det primære fokus for den sociale indsats er ofte disse andre ydelser, der leveres i forbindelse med opholdet. Der kan være egenbetaling for borgerens ophold. Det kan fx omfatte betaling for husleje, el, varme, vand, kost og vask. Vejledende visitationsparagraf: Serviceloven § 108, Almenboligloven § 54, Friplejeboligloven, Ældreboligloven m.fl."
        },
        {
          "code" : "80aa8ea7-4ad8-405f-876a-4c0f89fde06a",
          "display" : "Midlertidigt ophold",
          "definition" : "Midlertidigt ophold er en ydelse, der har til formål at huse en borger, og som tilkendes midlertidigt. Ophold leveres typisk af en type af botilbud. Ophold er i langt de fleste tilfælde én ud af flere ydelser, der leveres til borgeren af tilbuddet. Derfor betragtes ophold stort set altid som et tillæg til disse andre ydelser. Det primære fokus for den sociale indsats er ofte disse andre ydelser, der leveres i forbindelse med opholdet. Der kan være egenbetaling for borgerens ophold. Det kan fx omfatte betaling for husleje, el, varme, vand, kost og vask. Vejledende visitationsparagraf på Børn- og ungeområdet: Serviceloven §§ 52, 58, 66. Vejledende visitationsparagraf på Voksen-området: Serviceloven §§ 107, 109, 110."
        },
        {
          "code" : "a81a3fa9-6601-4d1e-a11e-f7444dfd3828",
          "display" : "Akut ophold",
          "definition" : "Akut ophold leveres til en persone med et pludseligt opstået behov for husning. Akut ophold leveres typisk på en type af botilbud eller andeet overnatningssted fx vandrehjem. Akut ophold kan være én af flere ydelser, der leveres til personen. Det kan være egenbetaling for personens ophold."
        }]
      },
      {
        "code" : "a2256d86-1cf8-4da5-be49-1f49f4335ecb",
        "display" : "Aktivitet og samvær",
        "definition" : "Aktivitet- og samvær er en ydelse, der gennem udviklende eller vedligeholdende aktiviteter har til formål at fremme socialt samvær eller at tilbyde et miljøskift. I aktivitet og samvær kan der også indgå individuel vejledning, støtte, omsorg og hjælp til at deltage i aktiviteterne. Lovhjemmel: Serviceloven § 104.",
        "concept" : [{
          "code" : "299af83f-586c-4c17-8af6-c8c47a847d6d",
          "display" : "Sansestimulerende aktivitet",
          "definition" : "Sansestimulerende aktiviteter er aktivitet og samvær, hvor en borger får stimuleret sine sanser med henblik på evnen til at kunne sortere, organisere og bearbejde sanseindtryk. Sansestimulerende aktiviteter kan fx være massage, gyngeture, kuglebad og -dyne, sansehave og brug af musik-, lyd- og lysstimuli. Visitationsparagraf: Serviceloven § 104."
        },
        {
          "code" : "2c1944be-fe87-4c42-b08e-9cc075c9ef18",
          "display" : "Oplevelsesaktivitet",
          "definition" : "Oplevelsesaktiviteter er aktivitet og samvær, hvor en borger har individuelle oplevelser eller oplevelser sammen med andre borgere eller personale. Oplevelser kan fx være natur- og kulturoplevelser. Visitationsparagraf: Serviceloven § 104."
        },
        {
          "code" : "66e23d66-1c5f-4070-bed1-8827cc863dcd",
          "display" : "Fysisk aktivitet",
          "definition" : "Fysiske aktiviteter er aktivitet og samvær, der gennem fysiske bevægelser giver en borger mulighed for at bruge sin krop. Det omfatter fx idræts- og motionsaktiviteter og forskellige former for bevægelse, hvor samværet kan være i centrum. Visitationsparagraf: Serviceloven § 104."
        },
        {
          "code" : "7e419926-bb04-4829-99c9-95ea20403c2c",
          "display" : "Social aktivitet",
          "definition" : "Social aktivitet er aktivitet og samvær, som ved at få en borger ind i et fællesskab med andre, forebygger eller bryder med social isolation og vedligeholder de sociale relationer. Social aktivitet kan fx være at spise, spille spil eller høre musik sammen med andre. Visitationsparagraf: Serviceloven § 104."
        },
        {
          "code" : "be5d5058-ef06-42a9-b894-51e44513e717",
          "display" : "Kreativ aktivitet",
          "definition" : "Kreative aktiviteter er aktivitet og samvær, hvor en borger kan udfolde sig kreativt. Aktiviteterne kan foretages alene eller sammen med andre borgere eller personale. Kreative aktiviteter kan fx være madlavning; musik, sang og drama; håndarbejde; maleri eller værkstedsaktiviteter. Visitationsparagraf: Serviceloven § 104."
        },
        {
          "code" : "f25674bf-3162-45c3-bde4-6d542bf9629b",
          "display" : "Kompetenceudviklende aktivitet",
          "definition" : "Kompetenceudviklende aktiviteter er aktivitet og samvær, hvor en borger eller gruppe af borgere undervises i bestemte færdigheder eller kompetencer. Kompetenceudviklende aktiviteter kan således både sigte på at opnå helt konkrete færdigheder fx i forhold til brug af IT og mobiltelefon eller på at lave mad, eller på mere brede kompetenceløft, der sigter mod evnen til at varetage egen sundhed og livsførelse. Visitationsparagraf: Serviceloven § 104."
        }]
      },
      {
        "code" : "d8505298-6ea5-4ca8-923d-6e4451cc9a48",
        "display" : "Beskyttet beskæftigelse",
        "definition" : "Beskyttet beskæftigelse er en ydelse, der gennem arbejdslignende, lønnede aktiviteter har til formål at afdække, oparbejde, udvikle eller bevare en borgers arbejdsevne og beskæftigelsesrelevante kompetencer. I beskyttet beskæftigelse kan der også indgå individuel vejledning, støtte og hjælp til at deltage i aktiviteterne. Beskyttet beskæftigelse er rettet mod borgere, der ikke kan opnå eller fastholde beskæftigelse på normale vilkår på arbejdsmarkedet, og som ikke kan få indsatser efter anden lovgivning. Lovhjemmel: Serviceloven § 103.",
        "concept" : [{
          "code" : "55b77d7c-afce-4269-9232-7731ab1ef4fc",
          "display" : "Service",
          "definition" : "Service og tjenesteydelser er beskyttet beskæftigelse, der er centreret omkring udførelse af servicerende, understøttende arbejdsfunktioner. I en service og tjenesteydelse vil der ofte indgå kontakt med andre, hvorfor der typisk vil være fokus på at træne dette. Eksempler på service og tjenesteydelser er kantine- og cafédrift, pedel- og rengøringsopgaver samt kontor- og piccolineopgaver, butik- og kundebetjening og vedligeholdelse af grønne områder. Visitationsparagraf: Serviceloven § 103."
        },
        {
          "code" : "c429b7a9-5085-472b-b118-a21ca90f769f",
          "display" : "Praktikforløb",
          "definition" : "Praktikforløb er beskyttet beskæftigelse, der har til formål, at en borger kan afprøve ressourcer og kompetencer i forhold til et specifikt arbejdsområde eller en given arbejdsplads i en afgrænset periode. Praktikforløb kan også foregå i en ekstern virksomhed, fx en dagligvareforretning eller en produktionsvirksomhed. Visitationsparagraf: Serviceloven § 103."
        },
        {
          "code" : "fb3d8722-90e0-4a80-ba65-490617ffeb0f",
          "display" : "Produktion og værksted",
          "definition" : "Produktion og værksted er beskyttet beskæftigelse, der er centreret omkring udførelse af enkle, afgrænsede arbejdsopgaver som led i en samlet produktion af konkrete produkter. De konkrete arbejdsopgaver kan fx være fremstilling af produkter, herunder fx kunsthåndværk, optændingsbrænde, grøntsager, produktion af avis og medier. Opgaverne kan eksempelvis omfatte montering, sortering, optælling og pakning og kontrol af produkter. Visitationsparagraf: Serviceloven § 103."
        }]
      },
      {
        "code" : "1f0ff82b-3243-422f-9651-1d00fd2dcd61",
        "display" : "Socialpædagogisk støtte",
        "definition" : "Socialpædagogisk støtte er en ydelse, der gennem motivation, vejledning og støtte har til formål at udvikle eller fastholde en borgers funktionsevne og muligheder for selvstændighed og selvbestemmelse i forhold til borgerens situation. Socialpædagogisk støtte retter sig blandt andet mod udvikling og vedligeholdelse af færdigheder i forbindelse med almindelig daglig livsførelse, herunder at skabe struktur i hverdagen og understøtte deltagelse i samfundets almene fællesskaber, eksempelvis uddannelse, beskæftigelse og foreningsliv. Socialpædagogisk støtte kan også ydes med det formål at begrænse tabet af funktionsevne og at yde kompensation, omsorg og pleje. Lovhjemmel: Serviceloven § 85.",
        "concept" : [{
          "code" : "309b778e-52ed-448a-91ae-0650a6cd8b1b",
          "display" : "Støtte til samfundsdeltagelse",
          "definition" : "Støtte til samfundsdeltagelse er socialpædagogisk støtte, der retter sig mod aktiviteter, der er en forudsætning for at kunne deltage i samfundslivet. Visitationsparagraf: Serviceloven § 85.",
          "concept" : [{
            "code" : "0886a1b6-4a3a-47e5-9c97-066270529e4f",
            "display" : "Støtte til transport",
            "definition" : "Socialpædagogisk støtte til transport er motivation, vejledning og støtte til samfundsdeltagelse, der retter sig mod en borgers mulighed for selvstændigt at færdes uden for hjemmet. Støtte til transport omfatter eksempelvis træning i at anvende offentlige transportmidler, fx at tage med bussen til og fra arbejde og uddannelse, behandling og lægebesøg eller aktiviteter af social karakter. Støtte til transport er ikke ledsagelse, men er rettet mod personens evne til at færdes selvstændigt. Visitationsparagraf: Serviceloven § 85."
          },
          {
            "code" : "1a2daf63-0510-4bf3-8578-662d4300c965",
            "display" : "Støtte til uddannelse",
            "definition" : "Socialpædagogisk støtte til uddannelse er motivation, vejledning og støtte til samfundsdeltagelse, der retter sig mod en borgersmuligheder for at varetage en uddannelse. Støtte til uddannelse kan fx være at afdække ønsker og muligheder i forbindelse med uddannelse, etablering af hensigtsmæssige rutiner og struktur i forhold til at varetage en uddannelse samt at fastholde motivation og engagement. Herved adskiller støtte til uddannelse sig fra specialpædagogisk støtte under uddannelse efter Lov om specialpædagogisk støtte. Støtte til uddannelse er helt eller delvist sammenfaldende med mentorstøtte efter Lov om aktiv beskæftigelsesindsats § 31.b Med uddannelse menes både ordinær uddannelse såvel som uddannelse på særlige vilkår. Visitationsparagraf: Serviceloven § 85."
          },
          {
            "code" : "cb1169ee-8969-46d3-813d-f0dd555bd838",
            "display" : "Støtte til beskæftigelse",
            "definition" : "Socialpædagogisk støtte til beskæftigelse er motivation, vejledning og støtte til samfundsdeltagelse, der retter sig mod en borgers muligheder for at varetage et arbejde. Støtte til beskæftigelse kan fx være etablering af hensigtsmæssige rutiner og struktur i forhold til at varetage et arbejde samt at fastholde motivation og engagement. Støtte til beskæftigelse er helt eller delvist sammenfaldende med mentorstøtte efter Lov om aktiv beskæftigelsesindsats § 31.b. Med beskæftigelse menes både ordinær beskæftigelse og beskæftigelse på særlige vilkår. Visitationsparagraf: Serviceloven § 85."
          },
          {
            "code" : "e2631dec-fd8b-420e-94db-53fd80e82766",
            "display" : "Støtte til kontakt til offentlige og private instanser",
            "definition" : "Socialpædagogisk støtte til kontakt til offentlige og private instanser er motivation, vejledning og støtte til samfundsdeltagelse, der retter sig mod gennemførsel af besøg hos og kontakt til offentlige og private instanser med et specifikt formål. Støtte til kontakt til offentlige og private instanser kan fx være rettet mod at henvende sig hos banken, foreninger, organisationer og offentlige myndigheder. Det kan også være støtte til at gennemføre besøg fx hos lægen eller tandlægen. Visitationsparagraf: Serviceloven § 85."
          }]
        },
        {
          "code" : "329782cf-a740-4eb7-aa7e-aaaa9a53c99e",
          "display" : "Støtte til sundhed",
          "definition" : "Støtte til sundhed er socialpædagogisk støtte, der retter sig mod et eller flere aspekter af sundhed og indeholder et element af sundhedsfremme. Sundhed omfatter både fysisk og mental trivsel. Visitationsparagraf: Serviceloven § 85.",
          "concept" : [{
            "code" : "3c1639d0-e486-43c6-8add-448b8aff4b8f",
            "display" : "Støtte til sund levevis",
            "definition" : "Socialpædagogisk støtte til sund levevis er motivation, vejledning og støtte til sundhed, der retter sig mod livsstilsbetingede forhold. Støtte til sund levevis kan fx være at dyrke motion, etablere en sund døgnrytme, stoppe med at ryge eller motivere borgeren til at spise sundt og hensigtsmæssigt, herunder støtte til måltider. Vejledende visitationsparagraf: Serviceloven § 85."
          },
          {
            "code" : "72272d03-1774-4a14-b598-5f19b5eac83f",
            "display" : "Støtte til personlig hygiejne",
            "definition" : "Socialpædagogisk støtte til personlig hygiejne er motivation, vejledning og støtte til sundhed, der retter sig mod hygiejnemæssige opgaver i relation til borgeren selv. Støtte til personlig hygiejne kan fx være rettet mod etablering af struktur og rutiner i forbindelse med af- og påklædning og bad. Herved adskiller støtte til personlig hygiejne sig fra personlig hjælp efter serviceloven § 83. Visitationsparagraf: Serviceloven § 85."
          },
          {
            "code" : "ad7755d2-11bf-468d-958b-2f0c8d9c3742",
            "display" : "Støtte til psykisk trivsel",
            "definition" : "Socialpædagogisk støtte til psykisk trivsel er motivation, vejledning og støtte til sundhed, der retter sig mod en borgers psykiske velbefindende. Støtte til psykisk trivsel kan fx være rettet mod en borgers følelsesregulering og handlemønstre, indsigt i og forståelse af egen situation, opbygning af positivt selvværd og identitet. Visitationsparagraf: Serviceloven § 85."
          },
          {
            "code" : "bd5fea9a-16ed-4e63-b6a1-8e83caaf9b0b",
            "display" : "Støtte til seksualitet",
            "definition" : "Socialpædagogisk støtte til seksualitet er motivation, vejledning og støtte til sundhed, der retter sig mod den måde, som en borgers seksualitet kommer til udtryk på. Støtte til seksualitet kan fx være støtte til at udtrykke sin seksualitet hensigtsmæssigt eller sætte grænser. Det kan også være støtte til at opsøge specialiseret rådgivning og vejledning i forhold til seksualitet og funktionsnedsættelser. Visitationsparagraf: Serviceloven § 85."
          },
          {
            "code" : "e7c8b42e-b882-4629-8e03-65e44b1aa3e3",
            "display" : "Støtte til behandling",
            "definition" : "Socialpædagogisk støtte til behandling er motivation, vejledning og støtte til sundhed, der retter sig mod en borgers behandling. Støtte til behandling kan fx være rettet mod, at borgeren fastholder beslutningen om at påbegynde behandling eller opretholder igangværende behandling, herunder fx misbrugsbehandling, psykologisk behandling og medicinsk behandling, Herved adskiller støtte til behandling sig fra ydelser efter Sundhedsloven § 138. Visitationsparagraf: Serviceloven § 85."
          }]
        },
        {
          "code" : "4ff4a2d4-4cde-4a22-bb37-ecfbd3fd9650",
          "display" : "Støtte til relationer og fællesskaber",
          "definition" : "Støtte til relationer og fællesskaber er socialpædagogisk støtte, der retter sig mod relationer og fællesskaber, hvor samspillet med andre er et centralt element. Visitationsparagraf: Serviceloven § 85.",
          "concept" : [{
            "code" : "05cd5e81-1a3a-4bdd-901b-7ec96c12d990",
            "display" : "Støtte til sociale relationer",
            "definition" : "Socialpædagogisk støtte til sociale relationer er motivation, vejledning og støtte til relationer og fællesskaber, der retter sig mod at udvikle, indgå i og bevare relationer til andre mennesker. Støtte til sociale relationer kan både være rettet mod en borgers relationer til enkeltpersoner eller på, hvordan en borger indgår i et større fællesskab. Støtte til sociale relationer kan både være hjælp til at håndtere de følelsesmæssige og sociale aspekter ved samværet, fx at håndtere følelser og problemstillinger i sociale sammenhænge, at skabe og fastholde netværk og at holde kontakt med venner og familie eller deltage i og gennemføre aktiviteter sammen med andre. Visitationsparagraf: Serviceloven § 85."
          },
          {
            "code" : "ea47a198-7e24-472d-ba5d-132b8b744710",
            "display" : "Støtte til varetagelse af forældrerollen",
            "definition" : "Socialpædagogisk støtte til varetagelse af forældrerollen er motivation, vejledning og støtte til relationer og fællesskaber, der retter sig mod strukturering og håndtering af opgaver, som er en almindelig del af forældreansvaret, og hvor samværet mellem barn og forælder er centralt. Støtten tildeles på baggrund af borgerens nedsatte funktionsevne i forhold til at gennemføre de opgaver, der indgår i varetagelse af forældrerollen og ikke grundet manglende forældreevne. Herved adskiller støtte til varetagelse af forældrerollen sig fra foranstaltninger efter Serviceloven § 52, hvor fokus er på barnets trivsel. Visitationsparagraf: Serviceloven § 85."
          }]
        },
        {
          "code" : "a63f7092-63d9-4cb5-ace5-655b552fdacc",
          "display" : "Støtte til praktiske opgaver",
          "definition" : "Støtte til praktiske opgaver er socialpædagogisk støtte, der retter sig imod almindelige praktiske opgaver. Støtte til praktiske opgaver består af motivation, vejledning og støtte til udførelsen af de praktiske opgaver, herunder udvikling og vedligeholdelse af kompetencer til at strukturere, planlægge og udføre de konkrete aktiviteter. Herved adskiller støtte til praktiske opgaver sig fra praktisk hjælp efter § 83. Visitationsparagraf: Serviceloven § 85.",
          "concept" : [{
            "code" : "638f44df-6bf2-47f8-9935-b8fdc83e5bf5",
            "display" : "Støtte til daglige opgaver i hjemmet",
            "definition" : "Socialpædagogisk støtte til daglige opgaver i hjemmet er motivation, vejledning og støtte til praktiske opgaver, der har hverdagskarakter og retter sig mod borgerens hjem. Støtte til daglige opgaver i hjemmet kan eksempelvis være støtte til oprydning, tøjvask, rengøring eller indkøb og madlavning. Visitationsparagraf: Serviceloven § 85."
          },
          {
            "code" : "c56634ca-6847-4c50-b5c1-c528c1ffc1d8",
            "display" : "Støtte til etablering i bolig",
            "definition" : "Socialpædagogisk støtte til etablering i bolig er motivation, vejledning og støtte til praktiske opgaver, der retter sig mod anskaffelse af og etablering i borgerens bolig. Et eksempel på støtte til etablering i bolig er at søge efter en bolig eller at guide og motivere i forbindelse med ind- og udflytning fx i forbindelse med planlægning, strukturering og gennemførsel af praktiske opgaver og indretning af boligen til borgerens behov. Visitationsparagraf: Serviceloven § 85."
          },
          {
            "code" : "d473dea2-4f6d-4f36-a8f0-260f0213f50a",
            "display" : "Støtte til administration",
            "definition" : "Socialpædagogisk støtte til administration er motivation, vejledning og støtte til praktiske opgaver af administrativ eller økonomisk karakter. Støtte til administration kan fx være rettet mod borgerens håndtering og forståelse af post, herunder digital post og selvbetjeningsløsninger, personlig økonomi, herunder budget, opsparing og regninger, samt opdatering og anvendelse af software eller apps, herunder digitaliserede hjælpemidler. Visitationsparagraf: Serviceloven § 85."
          }]
        }]
      },
      {
        "code" : "21dca9cf-c238-465b-9f12-15351f51b038",
        "display" : "Forebyggende hjælp og støtte",
        "definition" : "Forebyggende hjælp og støtte er en ydelse til voksne, der retter sig mod personer med lettere fysisk elle psykisk funktionsnedsættelse eller lettere sociale problemer og personer, der er i risiko for at udvikle funktionsnedsættelse eller sociale problemer. Forebyggende hjælp og støtte har til formål at forbedre personens aktuelle funktionsniveau eller den sociale problematik, eller forebygge at funktionsnedsættelsen eller de sociale problemer udvikles eller forværres.",
        "concept" : [{
          "code" : "3459f530-7334-48c4-9037-53bf80df8851",
          "display" : "Gruppebaseret hjælp og støtte",
          "definition" : "Gruppebaseret hjælp og støtte er forebyggende hjælp og støtte, der leveres til en gruppe af personer og kan fx bestå i træning, hjælp og støtte til udvikling af færdigheder, mestringskurser eller gruppesamtaler."
        },
        {
          "code" : "f3edac43-d0d6-4cc3-96c7-4658a557257a",
          "display" : "Akut rådgivning, omsorg og støtte",
          "definition" : "Akut rådgivning, omsorg eller støtte er forebyggende hjælp og støtte, der retter sig mod personer med psykiske vanskeligheder, der akut har brug for rådgivning, omsorg eller støtte. Ved akut forstås, at behovet er opstået pludseligt, og at det kræver øjeblikkelig levering af en given ydelse, der kan hindre forværring af eller stabilisere personens funktionsevne eller hindre, at sociale problemer forværres. Akut rådgivning, omsorg eller støtte kan fx leveres som telefonisk kontakt eller ved fremmøde, når en person møder op på et tilbud ved akut opstået behov."
        },
        {
          "code" : "fe42f8f4-d516-4bab-b006-12b0cd186603",
          "display" : "Individuel tidsbegrænset socialpædagogisk hjælp og støtte",
          "definition" : "Individuel, tidsbegrænset socialpædagogisk hjælp og støtte er forebyggende hjælp og støtte, der leveres i en på forhånd afgrænset periode til enkeltpersoner. Individuel tidsbegrænset socialpædagogisk hjælp og støtte kan gives i en periode på op til seks måneder med det formål at udvikle, forbedre eller forebygge tab af personens funktionsevne og muligheder for selvstændighed og selvbestemmelse i forhold til personens situation."
        },
        {
          "code" : "794ebc42-0639-46eb-aca2-40e996568578",
          "display" : "Hjælp og støtte etableret i samarbejde med frivillige",
          "definition" : "Hjælp og støtte etableret i samarbejde med frivillige er forebyggende hjælp og støtte, der leveres i samarbejde med frivillige sociale organisationer eller foreninger. Hjælp og støtte etableret i samarbejde med frivillige kan konkret leveres som henholdsvis gruppebaseret hjælp og støtte efter § 82a og individuel tidsbegrænset socialpædagogisk hjælp og støtte efter § 82 b.",
          "concept" : [{
            "code" : "b6e1f331-fccf-4a33-8bb6-566546edc405",
            "display" : "Gruppebaseret hjælp og støtte etableret i samarbejde med frivillige",
            "definition" : "Hjælp og støtte etableret i samarbejde med frivillige der konkret leveres som gruppebaseret hjælp og støtte efter § 82a"
          },
          {
            "code" : "d580bcb7-145a-4346-8e99-d387bbf08a40",
            "display" : "Individuel tidsbegrænset socialpædagogisk hjælp og støtte leveret i samarbejde med frivillige",
            "definition" : "Hjælp og støtte etableret i samarbejde med frivillige der konkret leveres som individuel tidsbegrænset socialpædagogisk hjælp og støtte efter § 82 b."
          }]
        }]
      }]
    },
    {
      "code" : "f708aea3-66bd-46c6-af11-7bf28942fa47",
      "display" : "Tilbud",
      "definition" : "Et tilbud er en organisation, der leverer ydelser.",
      "concept" : [{
        "code" : "5ea75f09-8eec-4edc-aafd-a330a523c33e",
        "display" : "Socialt akuttilbud",
        "definition" : "Et socialt akuttilbud er et tilbud til voksne, der retter sig mod personer med psykiske vanskeligheder, herunder psykisk sårbare, der oplever et akut behov for rådgivning, omsorg, støtte eller akut ophold, men som ikke har umiddelbart behov for psykiatrisk behandling. Ved akut behov forstås almindeligvis et behov, der er pludseligt opstået, og som fordrer øjeblikkelig levering af en given ydelse, der kan hindre forværring af eller stabilisere personens funktionsevne eller hindre, at sociale problemer forværres. Personen kan henvende sig anonymt og uanset aktuel boform."
      },
      {
        "code" : "d90f4da6-f87a-43b5-833f-646b4baf16d6",
        "display" : "Mobilt tilbud",
        "definition" : "Et mobilt tilbud er et tilbud, der ikke leverer ydelser til en borger på en bestemt matrikel, men flyttes ud, der hvor borgeren opholder sig. Det kan eksempelvis være i borgerens eget hjem, på et dagtilbud, et frivilligt tilbud eller i det offentlige rum, fx i forhold til hjemløse. Et mobilt tilbud leverer ydelser til borgere med nedsat fysisk eller psykisk funktionsevne eller sociale problemer, men som ikke har behov for et midlertidigt eller længerevarende ophold. Vejledende lovhjemmel: Serviceloven § 82a, § 82b, §82d, § 85"
      },
      {
        "code" : "7fec7d14-addb-4684-9637-403739de6228",
        "display" : "Dagtilbud til voksne",
        "definition" : "Et dagtilbud til voksne er et tilbud, der udelukkende leverer ydelser til en borger i dagtimerne. Dagtilbud adskiller sig fra ambulante tilbud ved varigheden af de ydelser, som leveres i tilbuddet, dvs. borgeren opholder sig i længere tid på dagtilbuddet. Et dagtilbud til voksne kan fx være et aktivitets- og samværstilbud eller et beskyttet beskæftigelsestilbud.",
        "concept" : [{
          "code" : "9401777d-bdc5-4f52-9804-63c8cae9a792",
          "display" : "Aktivitets- og samværstilbud",
          "definition" : "Et aktivitets- og samværstilbud er et dagtilbud til voksne, der gennem aktivitets- og samværsydelser fremmer socialt samvær eller tilbyder et miljøskift. Et aktivitets- og samværstilbud kan også levere andre ydelser ud over aktivitets- og samværsydelser. Begrebet dækker også uvisiterede væresteder og varmestuer. Lovhjemmel: Serviceloven § 104"
        },
        {
          "code" : "a0fb02a2-367c-48bc-bacd-92e49a861a4c",
          "display" : "Beskyttet beskæftigelsestilbud",
          "definition" : "Et beskyttet beskæftigelsestilbud er et dagtilbud til voksne, der leverer beskyttet beskæftigelses-ydelser med fokus på arbejdsevne og beskæftigelsesrelevante kompetencer til borgere, der ikke kan opnå eller fastholde beskæftigelse på normale vilkår på arbejdsmarkedet eller benytte arbejdsmarkedsrelaterede indsatser efter anden lovgivning. Lovhjemmel: Serviceloven § 103"
        }]
      },
      {
        "code" : "d23e3e8a-7fcf-4603-9d75-481b6e47e0eb",
        "display" : "Botilbudslignende tilbud",
        "definition" : "Et botilbudslignende tilbud er et tilbud, der ligner botilbud efter servicelovens § 107 eller § 108, men som er etableret efter anden lovgivning og opfylder betingelserne i socialtilsynsloven § 4, stk. 3. Den borger, der bor i et botilbudslignende tilbud, har lejeforhold efter den almene lejelov og bor i boligen på grund af nedsat fysisk eller psykisk funktionsevne eller særlige sociale problemer. De botilbudslignende tilbud adskiller sig desuden fra udgående tilbud efter servicelovens § 85 ved, at der er knyttet et serviceareal til boligen med fast personale, der overvejende leverer socialpædagogisk støtte. Begrebet omfatter ikke friplejeboliger. Vejledende lovhjemmel: Socialtilsynsloven § 4, stk. 1, nr. 3.",
        "concept" : [{
          "code" : "a7cbf55b-6906-4b2a-872e-c48b4d728837",
          "display" : "Almen ældre- og handicapvenlig bolig",
          "definition" : "En almen ældre- og handicapvenlig bolig er et botilbudslignende tilbud, der er oprettet som almennyttig bolig, og som retter sig mod ældre borgere og borgere med fysisk eller psykisk funktionsnedsættelse. I lovgivningen og vejledninger omtales de som \"almene ældreboliger\", men de kan rette sig både mod ældre borgere og mod borgere med nedsat fysisk eller psykisk funktionsevne. Lovhjemmel: Almenboligloven § 105"
        }]
      },
      {
        "code" : "2ecfcfe5-10ed-4934-a744-f18ce30b1619",
        "display" : "Botilbud til voksne",
        "definition" : "Et botilbud til voksne er et tilbud, der leverer ophold og oftest andre ydelser til en voksen borger.",
        "concept" : [{
          "code" : "25de7444-3919-4dab-b844-8cec6c15f30e",
          "display" : "Midlertidigt botilbud til voksne",
          "definition" : "Et midlertidigt botilbud til voksne er et botilbud til voksne, der retter sig mod borgere, som har midlertidig behov for støtte og hjælp, og som på sigt forventeligt kan få disse behov dækket på anden vis. Lovhjemmel: Serviceloven § 107"
        },
        {
          "code" : "96c97f55-a11b-47f8-aa52-6fdae4e804c2",
          "display" : "Længerevarende botilbud til voksne",
          "definition" : "Et længerevarende botilbud til voksne er et botilbud til voksne, der retter sig imod borgere, som har længerevarende behov for omfattende støtte og ophold, og som ikke kan få dækket disse behov på anden vis. Lovhjemmel: Serviceloven § 108",
          "concept" : [{
            "code" : "070016aa-e164-4813-aca5-b75acab89d63",
            "display" : "Sikret længerevarende botilbud til voksne",
            "definition" : "Et sikret botilbud er et længerevarende botilbud til voksne, som har længerevarende behov for omfattende støtte og ophold, og som ikke kan få dækket disse behov på anden vis. Et sikret botilbud omfatter mindst én afdeling eller lejlighed, som er godkendt til at have yderdøre og vinduer aflåst, og det modtager borgere i henhold til dom eller retskendelse. Lovhjemmel: Serviceloven § 108, stk. 7, nr. 1-3"
          },
          {
            "code" : "498fe92c-d7f7-41cd-9404-5b38fe113be0",
            "display" : "Almindeligt længerevarende botilbud til voksne",
            "definition" : "Et almindeligt længerevarende botilbud til voksne er et ikke-sikret, længerevarende botilbud til voksne, der retter sig mod borgere, som har længerevarende behov for omfattende støtte og ophold, og som ikke kan få dækket disse behov på anden vis. Lovhjemmel: Servicelovens § 108 stk. 1"
          }]
        }]
      }]
    },
    {
      "code" : "cda90d67-f65a-4a34-b8d8-168ee9ff0949",
      "display" : "Målgruppe",
      "definition" : "En målgruppe er en gruppe, hvis medlemmer en indsats er rettet imod.",
      "concept" : [{
        "code" : "0919515d-9975-4743-a16f-edb45374b0da",
        "display" : "Socialt problem",
        "definition" : "Et socialt problem er en tilstand, som er kendetegnet ved, at en person er, eller er i fare for at blive, marginaliseret. Ligesom det gør sig gældende for funktionsevnenedsættelse er også karakteren og rækkevidden af et socialt problem relativ til både personen selv og det omkringliggende samfund (dvs. personlige og omgivelsesmæssige faktorer). Socialt problem udgør sammen med nedsat fysisk og psykisk funktionsevne de tre overordnede målgrupper, som kan modtage ydelser efter Serviceloven.",
        "concept" : [{
          "code" : "122f3f8e-84a0-476f-b9c5-0e40b1dcf113",
          "display" : "Prostitution",
          "definition" : "Prostitution er en handling, hvor mindst to handlende personer på markedsmæssige betingelser henholdsvis køber og sælger en prostitutionsydelse mod betaling. Prostitution som socialt problem er kendetegnet ved, at en person er, eller er i fare for at blive, marginaliseret. Den tankemæssige forestilling om fænomenet prostitution er værdineutral. Inden for Servicelovens område er prostitution benævnt som type af socialt problem, men hvorvidt prostitution udgør et problem for den enkelte må afgøres på individniveau. Begrebet omfatter ikke forhold, der falder under de strafferetlige regler, fx køb af seksuelle ydelser, der sælges af unge under 18 år, eller det fænomen, at personer tvinges af andre til at sælge seksuelle ydelser."
        },
        {
          "code" : "16075f99-3694-4878-a48d-b2f4b515cb76",
          "display" : "Social isolation",
          "definition" : "Social isolation er en tilstand, hvor en person føler sig afsondret fra omverdenen."
        },
        {
          "code" : "293bf940-c075-4e3d-b5ef-6e331202e556",
          "display" : "Hjemløshed",
          "definition" : "Hjemløshed er tilstand, hvor en person ikke har en bolig. Hjemløshed som socialt problem er kendetegnet ved, at en person er, eller er i fare for at blive, marginaliseret. Begrebet dækker både husvilde, dvs. personer, der ikke har en bolig, og funktionelt hjemløse, dvs. personer, der har en bolig, men af den ene eller anden grund ikke kan opholde sig i den."
        },
        {
          "code" : "3b166cb0-df17-4002-a4c4-69e9a943645c",
          "display" : "Indadreagerende adfærd",
          "definition" : "Indadreagerende er en adfærd, hvor en person er præget af en lukket og indadrettet opførsel. Indadreagerende adfærd som socialt problem er kendetegnet ved, at en person er, eller er i fare for at blive, marginaliseret."
        },
        {
          "code" : "3e3f5ebf-82c1-401b-ab5e-e6138a31da3a",
          "display" : "Selvskadende adfærd",
          "definition" : "Selvskadende adfærd er adfærd, hvor en person intentionelt påfører eller kan påføre sig selv fysisk eller psykisk skade. Selvskadende adfærd som socialt problem, er kendetegnet ved, at en person er, eller er i fare for at blive, marginaliseret."
        },
        {
          "code" : "5e95db73-4d16-4084-93a3-595c0650b160",
          "display" : "Selvmordstanker eller -forsøg",
          "definition" : "Selvmordstanker eller -forsøg er en tilstand, hvor en person har tanker om at tage sit eget liv eller har forsøgt at begå selvmord."
        },
        {
          "code" : "66fac925-3488-43b3-8e50-4510d3821b37",
          "display" : "Andet socialt problem",
          "definition" : "socialt problem, der ikke er omfattet af en af de øvrige kategorier under socialt problem"
        },
        {
          "code" : "6fd0f315-2297-4d66-b638-3f867a0900e0",
          "display" : "Seksuelt krænkende adfærd",
          "definition" : "Seksuelt krænkende adfærd, er adfærd, hvor en person udsætter andre for grænseoverskridende seksuelle handlinger eller seksuelt overgreb. Seksuelt krænkende adfærd som socialt problem er kendetegnet ved, at en person er, eller er i fare for at blive, marginaliseret."
        },
        {
          "code" : "e1b59a4a-9cc2-4113-a5f1-84af588b02a2",
          "display" : "Udadreagerende adfærd",
          "definition" : "Udadreagerende adfærd er adfærd, der opleves aggressiv eller voldsom af omgivelserne. Udadreagerende adfærd som socialt problem er kendetegnet ved, at en person er, eller er i fare for at blive, marginaliseret."
        },
        {
          "code" : "f1f4d709-19d2-48cc-8942-231bf912323d",
          "display" : "Omsorgssvigt",
          "definition" : "Omsorgssvigt er en tilstand, hvor en person, der er afhængig af andre personer, ikke får den omsorg og hjælp, som denne har brug for. Omsorgssvigt som socialt problem er kendetegnet ved, at en person er, eller er i fare for at blive, marginaliseret. Omsorgssvigt kan omfatte fysisk omsorgssvigt, fx utilstrækkelig ernæring, beklædning og hygiejne og psykisk omsorgssvigt, fx manglende følelsesmæssig eller intellektuel stimulation eller der kan skelnes mellem passivt omsorgssvigt, fx manglende imødekommelse af basale behov og aktivt omsorgssvigt, fx direkte skade."
        },
        {
          "code" : "5c6bc9a0-a955-4168-9692-cdcd691ff866",
          "display" : "Overgreb",
          "definition" : "Overgreb er en handling, hvor en person eller dennes rettigheder krænkes af en stærkere part. Overgreb som socialt problem er kendetegnet ved, at en person er, eller er i fare for at blive, marginaliseret. Overgreb dækker bredt og er delvist overlappende med begrebet magtmisbrug, idet der er tale om en uretmæssig brug af en ikke-ligeværdig relation. Den ene persons stærkere position kan fx bero på alder, fysik, organisatoriske forhold, tradition m.v. Ligeledes begrænser krænkelsen af en person eller dennes rettigheder sig ikke til lovbrud, men kan fx også være latterliggørelse, manglende honorering af aftaler, tilbageholdelse af midler mv.",
          "concept" : [{
            "code" : "3412d671-22bf-456c-b963-c4e05c2725a0",
            "display" : "Voldeligt overgreb",
            "definition" : "Voldeligt overgreb er, når en person eller dennes rettigheder krænkes af en stærkere part, og hvor personen krænkes med fysisk eller psykisk vold. For at brugen af fysisk eller psykisk magt kan betegnes som vold, skal der være tale om en bevidst intention om at såre eller beskadige. For børn og unge omfatter voldeligt overgreb også at være vidne til fysisk eller psykisk vold i de nære relationer."
          },
          {
            "code" : "905caa77-2b98-48ce-b0e1-35dc4c1cc4bd",
            "display" : "Andet overgreb",
            "definition" : "overgreb, der ikke er omfattet af en af de øvrige kategorier under overgreb"
          },
          {
            "code" : "c47fd846-f1e0-4786-89a4-88d00e7a86c0",
            "display" : "Seksuelt overgreb",
            "definition" : "Seksuelt overgreb er, når en person eller dennes rettigheder krænkes af en stærkere part, og hvor personen udsættes for en seksuel krænkelse."
          }]
        },
        {
          "code" : "be53dafc-1fc2-4b9f-8ab3-9d468ff03e6e",
          "display" : "Kriminalitet",
          "definition" : "Kriminalitet er en handling, der er strafbar. Kriminalitet som socialt problem er kendetegnet ved, at en person er, eller er i fare for at blive, marginaliseret.",
          "concept" : [{
            "code" : "6a038911-d866-4910-90ae-72ca55c641ea",
            "display" : "Ikke-personfarlig kriminalitet",
            "definition" : "Ikke-personfarlig kriminalitet er en handling, der er strafbar, men som ikke påfører eller risikerer at påføre en person fysisk eller psykisk skade."
          },
          {
            "code" : "df42d472-06f6-4c5f-9dcf-64aa6cc20925",
            "display" : "Personfarlig kriminalitet",
            "definition" : "Personfarlig kriminalitet er en handling, der er strafbar og som påfører eller risikerer at påføre en person fysisk eller psykisk skade."
          }]
        },
        {
          "code" : "e2ecc751-21b9-4aab-a20f-2f3dd9701c97",
          "display" : "Misbrug",
          "definition" : "Misbrug er en adfærd, der er kendetegnet ved et brugsmønster af rusmiddel eller lægemiddel, som medfører fysisk, psykisk eller social skade. Som socialt problem er misbrug kendetegnet ved, at en person er, eller er i fare for at blive, marginaliseret. Skaden ved misbrug er ofte en kombination af fysisk, psykisk og social skade. Misbrug er kendetegnet ved, at en person indtager rusmidler, som ved gentagen anvendelse kan fremkalde fysisk og/eller psykisk afhængighed. Rusmidler omfatter opioider, benzodiazepiner, centralstimulantia, hallucinogener, cannabis og alkohol. (Nikotin, kaffe og te tilhører også gruppen, men er ikke medtaget i denne sammenhæng). En fysisk afhængighed er ikke det samme som et misbrug. Man kan godt være afhængig af et middel uden at være misbruger, fx kan en person være afhængig af livsvigtig medicin uden dermed at have et misbrug. Mange brugere af psykoaktive stoffer tager mere end en type af stoffer. Undergrupper af misbrug er klassificeret efter det stof, som har forårsaget eller bidraget mest til den foreliggende problemstilling. Opdelingen i alkoholmisbrug og stofmisbrug er yderligere baseret på de lovgivningsmæssige og organisatoriske rammer for behandlingen samt forskellige klientgrupper.",
          "concept" : [{
            "code" : "0e25a2ec-4f04-4d14-a5ad-a6519a7d1d5f",
            "display" : "Stofmisbrug",
            "definition" : "Stofmisbrug er misbrug, hvor rusmidlet ikke er alkohol. Misbrug er en adfærd, der der kendetegnet ved et brugsmønster af rusmiddel eller lægemiddel, som medfører fysisk, psykisk eller social skade. Skaden ved misbrug er ofte en kombination af fysisk, psykisk og social skade. Misbrug er kendetegnet ved, at en person indtager rusmidler, som ved gentagen anvendelse kan fremkalde fysisk og/eller psykisk afhængighed. Rusmidler omfatter opioider, benzodiazepiner, centralstimulantia, hallucinogener, cannabis og alkohol. (Nikotin, kaffe og te tilhører også gruppen, men er ikke medtaget i denne sammenhæng). En fysisk afhængighed er ikke det samme som et misbrug. Man kan godt være afhængig af et middel uden at være misbruger, fx kan en person være afhængig af livsvigtig medicin uden dermed at have et misbrug. Mange brugere af psykoaktive stoffer tager mere end en type af stoffer. Undergrupper af misbrug er klassificeret efter det stof, som har forårsaget eller bidraget mest til den foreliggende problemstilling. Opdelingen i alkoholmisbrug og stofmisbrug er yderligere baseret på de lovgivningsmæssige og organisatoriske rammer for behandlingen samt forskellige klientgrupper."
          },
          {
            "code" : "ab4413f0-fa81-41c0-ad8c-21782c12a0fa",
            "display" : "Alkoholmisbrug",
            "definition" : "Alkoholmisbrug er misbrug, hvor rusmidlet er alkohol. Misbrug er en adfærd, der er kendetegnet ved et brugsmønster af rusmiddel eller lægemiddel, som medfører fysisk, psykisk eller social skade. Skaden ved misbrug er ofte en kombination af fysisk, psykisk og social skade. Misbrug er kendetegnet ved, at en person indtager rusmidler, som ved gentagen anvendelse kan fremkalde fysisk og/eller psykisk afhængighed. Rusmidler omfatter opioider, benzodiazepiner, centralstimulantia, hallucinogener, cannabis og alkohol. (Nikotin, kaffe og te tilhører også gruppen, men er ikke medtaget i denne sammenhæng). En fysisk afhængighed er ikke det samme som et misbrug. Man kan godt være afhængig af et middel uden at være misbruger, fx kan en person være afhængig af livsvigtig medicin uden dermed at have et misbrug. Mange brugere af psykoaktive stoffer tager mere end en type af stoffer. Undergrupper af misbrug er klassificeret efter det stof, som har forårsaget eller bidraget mest til den foreliggende problemstilling. Opdelingen i alkoholmisbrug og stofmisbrug er yderligere baseret på de lovgivningsmæssige og organisatoriske rammer for behandlingen samt forskellige klientgrupper."
          }]
        }]
      },
      {
        "code" : "f3ec0ccd-2b0c-4a60-85fc-3cdd0ca73cef",
        "display" : "Funktionsnedsættelse",
        "definition" : "En funktionsnedsættelse er en funktionsevnenedsættelse, der vedrører kroppens anatomi eller kroppens funktion, herunder også mentale funktioner. Funktionsnedsættelse relaterer sig til kropslige begrænsninger, både begrænsninger i kroppens anatomi og begrænsninger i kroppens funktioner. Til sidstnævnte hører også begrænsninger i mentale funktioner.",
        "concept" : [{
          "code" : "1f23325e-c9c9-455b-bfe7-b4dcd1bb63e5",
          "display" : "Sjældent forekommende funktionsnedsættelse",
          "definition" : "En sjældent forekommende funktionsnedsættelse er en funktionsnedsættelse i kroppens anatomi eller kroppens funktion, herunder også mentale funktioner, som er sjældent forekommende. For at en funktionsnedsættelse kan karakteriseres som sjælden, må den have en forekomst på mindre end ca. 1.000 diagnosticerede tilfælde i Danmark. Begrebet rummer syndromer, der medfører udtalt fysisk og/eller psykisk funktionsnedsættelse, og som typisk er medfødte og arvelige."
        },
        {
          "code" : "f1c7ee41-21b4-4dba-9424-c874bf72b5e7",
          "display" : "Multipel funktionsnedsættelse",
          "definition" : "En multipel funktionsnedsættelse er en funktionsnedsættelse i kroppens anatomi eller kroppens funktion, herunder også mentale funktioner, som er kendetegnet ved et manglende talesprog. Multipel funktionsnedsættelse er mere end blot en flerhed af problemstillinger. Det er kendetegnende for personer med multiple funktionsnedsættelser, at de ikke har et talesprog, og at de lever med mobilitetsnedsættelse og eventuelt syns- og hørenedsættelse og øvrige sansefunktionsnedsættelser i forskellige kombinationer samt en dårlig helbredstilstand, der bl.a. kommer til udtryk i store spise- og trivselsvanskeligheder, kropsspændinger, kramper og smerter. Gruppen har store medfødte eller tidligt erhvervede neurologiske og kortikale skader og har mellem 2 og 10 diagnoser, med et gennemsnit på 5. De hyppigste diagnoser er cerebral parese og muskelsygdom, mental retardering, synshandicap, medfødte misdannelser og epilepsi."
        },
        {
          "code" : "112cc0ba-9953-476c-a971-2671697d7639",
          "display" : "Fysisk funktionsnedsættelse",
          "definition" : "En fysisk funktionsnedsættelse er en funktionsnedsættelse i kroppens anatomi eller kroppens funktioner, eksklusiv de mentale funktioner. Fysisk funktionsnedsættelse svarer til Servicelovens 'nedsat fysisk funktionsevne' og udgør sammen med nedsat psykisk funktionsevne og socialt problem de tre overordnede målgrupper, som kan modtage ydelser efter Serviceloven.",
          "concept" : [{
            "code" : "5cb8997c-eb10-477f-b653-b2a5ff11ce7d",
            "display" : "Kommunikationsnedsættelse",
            "definition" : "En kommunikationsnedsættelse er en begrænsning i en persons evne til at frembringe meddelelser som resultat af en funktionsnedsættelse i kroppens anatomi eller funktioner, eksklusiv de mentale funktioner. Begrænsning dækker hele spektret fra let nedsat til fuldstændig ophævet funktion. Kommunikationsnedsættelse omfatter ikke manglende evne til at forstå meddelelser, der ofte vil være del af en psykisk funktionsnedsættelse."
          },
          {
            "code" : "615310e8-f702-4455-910b-9d6d8aa684fb",
            "display" : "Synsnedsættelse",
            "definition" : "En synsnedsættelse er en begrænsning i en persons evne til at se som resultat af en funktionsnedsættelse i kroppens anatomi eller funktioner, eksklusiv de mentale funktioner Evnen til at se omfatter fx synsskarphed, synsfelt eller synskvalitet. Begrænsning dækker hele spektret fra betydeligt nedsat til fuldstændig ophævet funktion. Synsnedsættelse udgør kun en funktionsevnenedsættelse for så vidt som nedsættelsen rækker ud over det, der almindeligvis kan korrigeres for."
          },
          {
            "code" : "6e155207-db12-419a-8d9c-d67756533056",
            "display" : "Mobilitetsnedsættelse",
            "definition" : "En mobilitetsnedsættelse er en begrænsning i en persons mulighed for at bevæge sig som resultat af en funktionsnedsættelse i kroppens anatomi eller funktioner, eksklusiv de mentale funktioner. Begrænsning dækker hele spektret fra let nedsat til fuldstændig ophævet funktion."
          },
          {
            "code" : "7ef8be83-90d1-4375-b1cb-24710bea21c7",
            "display" : "Hørenedsættelse",
            "definition" : "En hørenedsættelse er en begrænsning i en persons opfattelse af lyd som resultat af en funktionsnedsættelse i kroppens anatomi eller funktioner, eksklusiv de mentale funktioner. Begrænsning dækker hele spektret fra betydeligt nedsat til fuldstændig ophævet funktion. Hørenedsættelse udgør kun en funktionsevnenedsættelse for så vidt som nedsættelsen rækker ud over det, der almindeligvis kan korrigeres for."
          },
          {
            "code" : "da298aec-cd7d-436c-9927-d88d00066881",
            "display" : "Anden fysisk funktionsnedsættelse",
            "definition" : "fysisk funktionsnedsættelse, der ikke er omfattet af en af de øvrige kategorier under fysisk funktionsnedsættelse"
          },
          {
            "code" : "04a2ecdd-cdc6-4000-91d3-4e21958126ec",
            "display" : "Døvblindhed",
            "definition" : "Døvblindhed er en fysisk funktionsnedsættelse, der består af en kombineret syns- og hørenedsættelse i alvorlig grad.",
            "concept" : [{
              "code" : "0d66b364-958e-48cf-a18b-744fab284194",
              "display" : "Erhvervet døvblindhed",
              "definition" : "Erhvervet døvblindhed er en fysisk funktionsnedsættelse, der består af en kombineret syns- og hørenedsættelse i alvorlig grad, som er opstået efter et sprog er udviklet."
            },
            {
              "code" : "ab7b7d7b-b7bb-4b8c-99d9-5c98a302b771",
              "display" : "Medfødt døvblindhed",
              "definition" : "Medfødt døvblindhed er en fysisk funktionsnedsættelse, der består af en kombineret syns- og hørenedsættelse i alvorlig grad, som er opstået inden et sprog er udviklet."
            }]
          }]
        },
        {
          "code" : "9ed67228-b934-4677-9f7e-ebb0d80de44b",
          "display" : "Psykisk funktionsnedsættelse",
          "definition" : "En psykisk funktionsnedsættelse er en funktionsnedsættelse i de mentale funktioner. Psykisk funktionsnedsættelse svarer til Servicelovens 'nedsat psykisk funktionsevne' og udgør sammen med nedsat fysisk funktionsevne og socialt problem de tre overordnede målgrupper, som kan modtage ydelser efter Serviceloven.",
          "concept" : [{
            "code" : "a78fb31e-b30a-4815-af85-932859fd06b9",
            "display" : "Psykiske vanskeligheder",
            "definition" : "Psykiske vanskeligheder er en psykisk funktionsnedsættelse, der er kendetegnet ved forstyrrelser i adfærd og tanke-, følelses-, stemnings- og fantasilivet.",
            "concept" : [{
              "code" : "192b7d79-415c-4f4f-9223-607938ecbe97",
              "display" : "Spiseforstyrrelse",
              "definition" : "Spiseforstyrrelse er en forstyrrelse i adfærd og tanke-, følelses-, stemnings- og fantasilivet, der er kendetegnet ved et afvigende spisemønster. Som eksempel på spiseforstyrrelser kan nævnes anoreksi, bulimi og tvangsspisning."
            },
            {
              "code" : "303deb9b-84f0-49d2-ab7a-f8b98eed40a2",
              "display" : "Angst",
              "definition" : "Angst er en forstyrrelse i adfærd og tanke-, følelses-, stemnings- og fantasilivet, der er kendetegnet ved en følelse af frygt, anspændthed og uro, uden at det er muligt at identificere en umiddelbar årsag."
            },
            {
              "code" : "6aac5ae6-ef06-4866-9c66-16d51ebbc83b",
              "display" : "Personlighedsforstyrrelse",
              "definition" : "Personlighedsforstyrrelse er en forstyrrelse i adfærd og tanke-, følelses-, stemnings- og fantasilivet, der er kendetegnet ved en forstyrrelse i evnen til at forholde sig til andre mennesker. Begrebet dækker over borderline, psykopati og karakterafvigelser."
            },
            {
              "code" : "851b2a9d-cde2-4d5d-8f33-d03789022cbb",
              "display" : "Anden psykisk vanskelighed",
              "definition" : "psykiske vanskeligheder, der ikke er omfattet af en af de øvrige kategorier under psykiske vanskeligheder"
            },
            {
              "code" : "afaa7e31-2b5d-4a49-9008-56aa8df8dc13",
              "display" : "Stressbelastning",
              "definition" : "Stressbelastning er en forstyrrelse i adfærd og tanke-, følelses-, stemnings- og fantasilivet, hvor en person gennem længere tid befinder sig i en tilstand af konstant forhøjet fysisk og psykisk beredskab. Begrebet dækker et bredt spektrum af belastende tilstande gående fra konstant anspændthed, magtesløshed, uoverskuelighed eller vanskelighed ved at fortsætte i den forhåndenværende situation, eller nedsat evne til at gennemføre dagligdags gøremål, til posttraumatisk belastningsreaktion på baggrund af traumatiske begivenheder af exceptionelt truende eller katastrofal natur."
            },
            {
              "code" : "d42d8f41-2d07-4391-a687-bad51172d0c9",
              "display" : "Tilknytningsforstyrrelse",
              "definition" : "Tilknytningsforstyrrelse er en forstyrrelse i adfærd og tanke-, følelses-, stemnings- og fantasilivet, der er kendetegnet ved, at en person i en tidlig alder har oplevet omsorgssvigt og nu har svært ved at danne følelsesmæssige relationer til andre mennesker."
            },
            {
              "code" : "ee5b52bd-b839-4e69-ad04-c8b33eabfbde",
              "display" : "Depression",
              "definition" : "Depression er en forstyrrelse i adfærd og tanke-, følelses-, stemnings- og fantasilivet, der er kendetegnet ved en markant, vedvarende følelse af tristhed, håbløshed og handlingslammelse."
            },
            {
              "code" : "f2ccc0c0-2a0a-49c9-9d6a-741a7cd220a3",
              "display" : "Forandret virkelighedsopfattelse",
              "definition" : "Forandret virkelighedsopfattelse er en forstyrrelse i adfærd og tanke-, følelses-, stemnings- og fantasilivet, der er kendetegnet ved en virkelighedsopfattelse, der udgør en væsentlig afvigelse fra accepterede statistiske normer. Begrebet dækker over skizoide/psykotiske tilstande."
            }]
          },
          {
            "code" : "01da9924-f4b4-4265-8594-0e892fa60676",
            "display" : "Intellektuel/kognitiv forstyrrelse",
            "definition" : "Intellektuel/kognitiv forstyrrelse er en psykisk funktionsnedsættelse, der er kendetegnet ved forstyrrelser i overordnede mentale funktioner.",
            "concept" : [{
              "code" : "17ce646b-4469-4a73-82a9-9628436f6c70",
              "display" : "Anden intellektuel/kognitiv forstyrrelse",
              "definition" : "Intellektuel/kognitiv forstyrrelse, der ikke er omfattet af en af de øvrige kategorier under intellektuel/kognitiv forstyrrelse"
            },
            {
              "code" : "7b48f1a0-579b-4976-ae7c-4074b5981449",
              "display" : "Demens",
              "definition" : "Demens er en forstyrrelse i overordnede mentale funktioner, der er kendetegnet ved en fremadskridende nedsættelse af en persons intellektuelle og kognitive færdigheder, heriblandt hukommelsesfunktionen. Som eksempel på demens kan nævnes Alzheimers sygdom og vaskulær demens."
            },
            {
              "code" : "97c355cc-84e3-46d0-ac1b-00bc627d089f",
              "display" : "Udviklingshæmning",
              "definition" : "Udviklingshæmning er en forstyrrelse i overordnede mentale funktioner, der er kendetegnet ved en forsinket eller manglende udvikling inden for bestemte områder af psyken eller mere generel mental retardering. Begrebet omfatter også Down's syndrom."
            },
            {
              "code" : "34449052-1150-4900-9d69-c56eb9b26793",
              "display" : "Udviklingsforstyrrelse",
              "definition" : "En udviklingsforstyrrelse er en forstyrrelse i overordnede mentale funktioner, der er kendetegnet ved en dysfunktion eller nedsat funktion i hjernen.",
              "concept" : [{
                "code" : "5cfc9530-a193-4f66-9981-3b980ee9ea7b",
                "display" : "Anden udviklingsforstyrrelse",
                "definition" : "udviklingsforstyrrelse, der ikke er omfattet af en af de øvrige kategorier under udviklingsforstyrrelse"
              },
              {
                "code" : "71dfe6d1-ebc1-4414-8527-edf8e605c356",
                "display" : "Udviklingsforstyrrelse af tale og sprog",
                "definition" : "Udviklingsforstyrrelse af tale og sprog er en udviklingsforstyrrelse, hvor normale mønstre for sprogerhvervelse er påvirkede fra de tidligste udviklingstrin. Som eksempel på udviklingsforstyrrelser af tale og sprog kan nævnes specifik sprogartikulationsforstyrrelse (dysartri), sprogudtryksforstyrrelse (ekspressiv dysfasi) og sprogopfattelsesforstyrrelse (impressiv dysfasi)."
              },
              {
                "code" : "93d52b11-faa7-4ff7-b552-11a84cce8bf1",
                "display" : "Udviklingsforstyrrelse af skolefærdigheder",
                "definition" : "Udviklingsforstyrrelse af skolefærdigheder er en udviklingsforstyrrelse, hvor normale mønstre for udviklingen af intellektuelle skolefærdigheder er tilbagestående fra de tidligste udviklingstrin. Som eksempel på udviklingsforstyrrelse af skolefærdigheder kan nævnes specifik læseforstyrrelse (dysleksi), specifik staveforstyrrelse og specifik regnevanskelighed (dyskalkuli)."
              },
              {
                "code" : "9b3fd322-a75a-4ed8-9b74-425fa1e01c95",
                "display" : "Autismespektrum",
                "definition" : "Autismespektrum er en dysfunktion eller nedsat funktion i hjernen, der er kendetegnet ved en mangelfuld udvikling af sociale og kommunikative færdigheder samt repetitiv og stereotyp adfærd."
              },
              {
                "code" : "cc6a58cf-d3d2-4e5f-b7fe-98b009647eac",
                "display" : "Opmærksomhedsforstyrrelse",
                "definition" : "En opmærksomhedsforstyrrelse er en dysfunktion eller nedsat funktion i hjernen, der er kendetegnet ved betydelige opmærksomheds- og koncentrationsproblemer. Begrebet omfatter ADHD og ADD."
              },
              {
                "code" : "e6a269f5-944a-4ff8-b4d8-6dc2134d9167",
                "display" : "Udviklingsforstyrrelse af sansemotoriske færdigheder",
                "definition" : "Udviklingsforstyrrelse af sansemotoriske færdigheder er en udviklingsforstyrrelse, der er karakteriseret ved alvorlige forstyrrelser i udviklingen af motorisk koordination. Som eksempel på udviklingsforstyrrelse af motoriske færdigheder kan nævnes fumler-tumlersyndromet, udviklingsmæssig koordinationsforstyrrelse og udviklingsmæssig dyspraksi."
              }]
            },
            {
              "code" : "59254ffb-8efb-4023-84f8-73e5bcba0bc7",
              "display" : "Hjerneskade",
              "definition" : "Hjerneskade er en forstyrrelse i overordnede mentale funktioner, der er kendetegnet ved misdannet eller ødelagt hjernevæv.",
              "concept" : [{
                "code" : "1097d07f-1dba-4cc2-ae3a-399a501c2eb6",
                "display" : "Medfødt hjerneskade",
                "definition" : "En medfødt hjerneskade er misdannet eller ødelagt hjernevæv, som er opstået før eller under fødslen."
              },
              {
                "code" : "d26f97e8-99ed-46a9-94db-93340f77a950",
                "display" : "Erhvervet hjerneskade",
                "definition" : "En erhvervet hjerneskade er misdannet eller ødelagt hjernevæv, som er kommet til efter fødslen."
              }]
            }]
          }]
        }]
      }]
    }]
  },
  {
    "code" : "7ac451dc-773b-4877-baaf-1e6b1d5c8e28",
    "display" : "Støttebehovsniveau",
    "definition" : "Støttebehov er omfanget af en persons behov for udefrakommende støtte vurderet på baggrund af personens funktionsevne inden for forskellige livsområder. Omfanget vurderes ud fra, hvor ofte og hvor megen støtte personen skal have for at kunne overskue og udføre de aktiviteter, der er relevante for personen. Støttebehovet siger ikke noget om, hvilken specifik indsats personen har brug for, men det siger noget om omfanget af indsatsen, fordi den skal modsvare behovets omfang.",
    "concept" : [{
      "code" : "2254dac8-8aa3-4334-8502-9720194f49ad",
      "display" : "Ikke vurderet",
      "definition" : "Ikke vurderet"
    },
    {
      "code" : "401a397b-b3aa-4ca3-8b23-bd8f99dd3f76",
      "display" : "Moderat støttebehov",
      "definition" : "Moderat støttebehov"
    },
    {
      "code" : "ae9f388a-91c3-46cf-af55-f81952f2977c",
      "display" : "Intet støttebehov",
      "definition" : "Intet støttebehov"
    },
    {
      "code" : "b99a0790-4d70-4152-b149-3fe58b745583",
      "display" : "Højt støttebehov",
      "definition" : "Højt støttebehov"
    },
    {
      "code" : "dd628e73-d6c9-4837-a2b8-aa62d73bd6ae",
      "display" : "Let støttebehov",
      "definition" : "Let støttebehov"
    },
    {
      "code" : "e99763d6-6c43-4969-ad52-2b1a7055f9dc",
      "display" : "Fuldstændigt støttebehov",
      "definition" : "Fuldstændigt støttebehov"
    }]
  },
  {
    "code" : "90479ffa-bf46-4b3a-a172-91f2798e2a43",
    "display" : "Status på indsats",
    "definition" : "Status på indsats",
    "concept" : [{
      "code" : "1e971d84-10a4-4ef8-a8b3-0daa4c7d088a",
      "display" : "Træf afgørelse om fortsættelse af indsats",
      "definition" : "Træf afgørelse om fortsættelse af indsats"
    },
    {
      "code" : "b4c01aa8-82fd-44e4-83ff-ca19ec02c779",
      "display" : "Træf afgørelse om afslutning af indsats og visiter til ny",
      "definition" : "Træf afgørelse om afslutning af indsats og visiter til ny"
    },
    {
      "code" : "d7d03656-4c87-4e67-9146-aa5990460f16",
      "display" : "Træf afgørelse om afslutning af indsats",
      "definition" : "Træf afgørelse om afslutning af indsats"
    }]
  },
  {
    "code" : "b3ddc7d7-f6c1-4d47-8280-456992cbe0a6",
    "display" : "FFB tilstande",
    "definition" : "FFB tilstande",
    "concept" : [{
      "code" : "740934cd-002b-4b96-b92e-b3562eed9448",
      "display" : "Funktioner og forhold",
      "definition" : "Funktioner og forhold",
      "concept" : [{
        "code" : "25c5c614-305f-46cd-9891-55d564fc30cf",
        "display" : "Mentale funktioner",
        "definition" : "Mentale funktioner er hjernens funktioner - både overordnede mentale funktioner som bevidsthed, energi og handlekraft og specifikke mentale funktioner som hukommelse, sprog og regning.",
        "concept" : [{
          "code" : "17c35058-eb88-4a7a-8727-74cd12be42c7",
          "display" : "Opmærksomhed og koncentrationsevne",
          "definition" : "Opmærksomhed og koncentrationsevne er en mental funktion, der er bestemmende for fokusering på eksterne stimuli eller indre oplevelser så længe som nødvendigt. Begrebet omfatter fx en persons evne til at fastholde opmærksomhed, skift i opmærksomhed, opdeling af opmærksomhed, hvor der fokuseres på to eller flere stimuli på samme tid, samt deltagende opmærksomhed, hvor to eller flere personer fokuserer på det samme."
        },
        {
          "code" : "3591c972-5b15-4bbd-86c7-91622cda56e8",
          "display" : "Virkelighedsopfattelse",
          "definition" : "Virkelighedsopfattelse er den mentale funktion, der er bestemmende for genkendelse og fortolkning af sanseindtryk. Virkelighedsopfattelse adskiller sig fra de fysiske funktioner vedrørende sanserne ved at have fokus på, hvordan en person genkender og fortolker sanseindtrykkene og ikke, hvorvidt de sanses eller ej. Begrebet omfatter fx hallucinationer og vrangforestillinger."
        },
        {
          "code" : "4934e45a-0f93-4c23-a767-2b681378700b",
          "display" : "Bevidsthedstilstand",
          "definition" : "Bevidsthedstilstand er en mental funktion, der er bestemmende for vågenhed. Eksempler på bevidsthedstilstand kan være, at en person er vågen i perioder, men i andre perioder er i en vegetativ tilstand. Relevante aspekter af bevidsthedstilstand er fx hyppigheden eller varigheden af vågenhed, hvorvidt personen er i koma eller trance eller taber bevidstheden. Begrebet omfatter ikke, hvorvidt en person handler bevidst eller intentionelt og skal heller ikke forveksles med begrebet 'virkelighedsopfattelse' eller 'indsigt i egen situation'."
        },
        {
          "code" : "52e0b8dd-f5fa-4e1a-b66e-f5e4a41bd313",
          "display" : "Psykosociale funktioner",
          "definition" : "De psykosociale funktioner er en mental funktion, som udvikles gennem livet, og som er nødvendig for at danne, indgå i og fastholde relationer med andre mennesker. De psykosociale funktioner danner dermed baggrund for en persons sociale og mellemmenneskelige færdigheder. De omfatter fx evnen til at aflæse andres følelser eller sociale normer. De omfatter også psykologiske funktioner, som er en forudsætning for at indgå i relationer, fx selvværd og identitetsdannelse."
        },
        {
          "code" : "61452fe5-cea2-4d92-b2f1-406e9a5d31cb",
          "display" : "Hukommelse",
          "definition" : "Hukommelse er en mental funktion, der er bestemmende for registrering, lagring og genkaldelse af information efter behov. Hukommelse er fx korttidshukommelse og langtidshukommelse, herunder genkaldelse af information, der er gemt i langtidshukommelsen og bringes frem i bevidstheden. Eksempler på hukommelse kan være evnen til at huske aftaler, steder og personer, ligesom der kan skelnes mellem fx auditiv, visuel, taktil eller følelsesmæssig hukommelse."
        },
        {
          "code" : "6279a3dc-7085-4157-809c-f96922242b1b",
          "display" : "Indsigt i egen situation",
          "definition" : "Indsigt i egen situation er en mental funktion, der vedrører bevidsthed om og forståelse af en selv og egen adfærd. Indsigt i egen situation er fx en persons indsigt i en eventuel funktionsnedsættelse eller socialt problem og konsekvenserne heraf."
        },
        {
          "code" : "8028b034-cad2-42df-b51c-aaba9c0bba61",
          "display" : "Igangsætning og motivation",
          "definition" : "Igangsætning og motivation er en mental funktion, som får en person til at opnå tilfredsstillelse af specifikke behov og overordnede mål på en vedholdende måde. Igangsætning og motivation er fx en persons energiniveau, motivation, appetit og trang samt impulskontrol. Begrebet omfatter dermed en persons evne til at omsætte en tanke eller følelse i handling, hvor man tager initiativ til at igangsætte en aktivitet og afslutte den. Det at opnå eller bevare håb som vigtig motivationsfaktor er også omfattet af begrebet."
        },
        {
          "code" : "9c2173e6-6465-44d3-af16-7c44059193b2",
          "display" : "Organisering og planlægning",
          "definition" : "Organisering og planlægning er en mental funktion, der vedrører helhedsdannelse, systematisering og udvikling af metode til fremgangsmåde eller handling."
        },
        {
          "code" : "b93216fa-3843-4a7e-85bc-e3ef35a1967f",
          "display" : "Problemløsning",
          "definition" : "Problemløsning er en mental funktion, der er bestemmende for identifikation, analyse og integrering af uoverensstemmende eller modstridende informationer til en løsning. Problemløsning er dermed en persons evne til at løse problemer, herunder at identificere, at der er et problem, analysere det og fremkomme med en løsning."
        },
        {
          "code" : "dccaa419-0bcd-4056-a11a-2e385e23edc6",
          "display" : "Følelser og adfærd",
          "definition" : "Følelser og adfærd er en mental funktion, der er forbundet med følelser og en persons tilbøjelighed til at reagere på bestemte måder i forskellige situationer. Følelser og adfærd er fx, hvorvidt en person har følelser, der er afstemt eller passer til den situation, personen er i, og kan regulere sine følelser. Begrebet vedrører også personens følelsesmæssige spændvidde. Følelser kan komme til udtryk gennem adfærd. Eksempler på adfærd er ind- og udadreagerende adfærd, seksuelt krænkende adfærd, selvskadende adfærd eller selvmordsforsøg."
        },
        {
          "code" : "ef4271c4-f942-4194-a2b0-e9a7045eab22",
          "display" : "Intellektuelle funktioner",
          "definition" : "Den intellektuelle funktion er en overordnet mental funktion, som kræves til forståelse og integrering af forskellige mentale funktioner og deres udvikling over et livsløb. Begrebet har betydning i forhold til fx indlæringsevne og intellektuel formåen, herunder en persons skolefærdigheder. Begrebet omfatter ikke de eksekutive funktioner, så som organisering og planlægning, problemløsning og indsigt i egen situation."
        },
        {
          "code" : "f7c0ef6c-18ba-4d38-9df5-4c891f154a08",
          "display" : "Orienteringsevne",
          "definition" : "Orienteringsevne en en mental funktion, der er bestemmende for kendskab til og konstatering af relationerne til en selv, til andre, til tid, sted og andre omgivelser. Orienteringsevne er fx en persons evne til at orientere sig i tid og sted, rum og retning og forstå egen identitet og identiteten af personer i personens umiddelbare nærhed."
        }]
      },
      {
        "code" : "4fb78b88-d3af-4cfb-84d7-f06daf423317",
        "display" : "Sundhedsforhold",
        "definition" : "Sundhedsforhold er forhold, der påvirker en persons sundhed.",
        "concept" : [{
          "code" : "081ab1be-7dc1-41fa-803c-12a146eb0b74",
          "display" : "Sundhedsfaglig behandling og træning",
          "definition" : "Sundhedsfaglig behandling og træning er forhold vedrørende behandling og træning, som er bevilget efter sundhedsloven. Begrebet omfatter tidligere og nuværende behandling og træning, der er bevilget efter sundhedsloven, herunder medicinsk behandling. Begrebet omfatter ikke bevillinger efter serviceloven eller alternativ, uautoriseret behandling."
        },
        {
          "code" : "0b650369-258a-4d01-a811-42b306c2f89d",
          "display" : "Motion",
          "definition" : "Motion er en handling, hvor en person udfører regelmæssige, fysiske aktiviteter med henblik på at bevare et godt helbred og holde kroppen i form."
        },
        {
          "code" : "69dbfad7-859a-4596-8737-8054f6b4948f",
          "display" : "Fysisk helbred",
          "definition" : "Fysisk helbred er en egenskab hos et individ mht. sygdom og sundhed. Helbred handler om, hvorvidt en person er fysisk rask eller syg, fx om man er udsat for hyppige infektioner, har allergier eller en kronisk sygdom."
        },
        {
          "code" : "83376fdb-f55d-4dd9-944e-b49631a9836f",
          "display" : "Søvn",
          "definition" : "Søvn er en tilstand, hvis kvalitet afgøres af søvnmængden og forhold omkring indsovning og gennemsovning, og hvorvidt der er tale om en naturlig søvn med optimal fysisk og psykisk hvile og afslapning."
        },
        {
          "code" : "c67aed23-d4f3-4ae6-8886-156c99048e5b",
          "display" : "Kost",
          "definition" : "Kost er en persons indtagelse af fødemidler og deres sammensætning. Et relevant aspekt af kost er også, hvorvidt en person spiser og drikker tilstrækkeligt eller for lidt eller for meget."
        },
        {
          "code" : "c8f4475a-8de3-4920-ad0c-eea78c49a68d",
          "display" : "Rusmidler",
          "definition" : "En persons situation vedrørende rusmidler er den samlede mængde af forhold, der har at gøre med en persons brug af rusmidler. Et eksempel på en situation vedrørende rusmidler kan være en bekymrende hyppig brug af rusmidler eller selvmedicinering med hash. Eksempler på problematikker vedrørende rusmidler kan være alkohol- og stofmisbrug eller misbrug af lægemidler. Et eksempel på ressourcer vedrørende rusmidler kan være et gennemført behandlingsforløb."
        },
        {
          "code" : "e6f82424-da5a-41d1-bd1a-5796aa79d5f2",
          "display" : "Døgnrytme",
          "definition" : "Døgnrytme er den struktur, som en person inddeler døgnets forskellige aktiviteter i. Døgnrytmen opstår fx ved at spise, arbejde og sove på mere eller mindre fastlagte tidspunkter."
        },
        {
          "code" : "f5b8e809-7689-4952-838c-a069c99408b3",
          "display" : "Tobak",
          "definition" : "Tobak omfatter både cigaretter, pibe, vandpibe, e-cigaretter, snus mv."
        }]
      },
      {
        "code" : "a134c31d-d316-46d4-935e-e500874dbbe1",
        "display" : "Fysiske funktioner",
        "definition" : "Fysiske funktioner er kroppens funktioner eksklusiv de mentale funktioner.",
        "concept" : [{
          "code" : "1a6585e7-25a6-4518-9384-8f6290f879cc",
          "display" : "Stemme og tale",
          "definition" : "Stemme og tale er en fysisk funktion, der vedrører frembringelse af lyd og tale."
        },
        {
          "code" : "3b4bcb40-f761-46a5-bc5f-b30ac37c88ed",
          "display" : "Bevægelse",
          "definition" : "Bevægelse er en fysisk funktion, der vedrører bevægelse af kroppen. Bevægelse spænder bredt fra en persons reflekser, ufrivillige og viljesbestemte bevægelser til gang, løb eller andre bevægelser, som inddrager hele kroppen."
        },
        {
          "code" : "9959e779-e8ee-47e8-989b-bbff4aae2883",
          "display" : "Syn",
          "definition" : "Syn er en fysisk funktion, der vedrører opfattelse af lys og af form, størrelse og farve af visuelle stimuli."
        },
        {
          "code" : "b37419b3-c5f2-43e9-9e9d-4037b06b3fa5",
          "display" : "Smerte og sansefunktioner",
          "definition" : "Smerte og sansefunktioner er en fysisk funktion, der vedrører opfattelsen af sanseindtryk samt ubehagelige fornemmelser som tegn på potentiel eller aktuel skade eller tilstand på dele af kroppen. Sanseindtryk omfatter fx berøringssans, temperatursans, lugt- og smagssans samt opfattelsen af kropsdeles position i forhold til hinanden. Smerter omfatter også fantomsmerter."
        },
        {
          "code" : "eb3599bc-c0bb-4281-8a1c-bf6eab8ffde3",
          "display" : "Hørelse",
          "definition" : "Hørelse er en fysisk funktion, der vedrører opfattelse af lyde og skelnen af lokalisation, tone, styrke og kvalitet af lyde."
        }]
      },
      {
        "code" : "e1836145-0c20-4e20-971e-d62dfe4ea1a0",
        "display" : "Sociale forhold",
        "definition" : "Sociale forhold er tilstande, vilkår, hændelser eller andre personlige faktorer, som relaterer til en persons baggrund og historie, er af social karakter og har betydning for en persons funktionsevne. Sociale forhold kan enten beskytte mod eller føre til, at et socialt problem opstår.",
        "concept" : [{
          "code" : "08aa68ce-acd6-4e03-b6b5-091811324345",
          "display" : "Økonomisk situation",
          "definition" : "En persons økonomiske situation er den samlede mængde af forhold, der bestemmer, hvordan en person er stillet finansielt. Et eksempel på økonomisk situation kan være, at man er på kontanthjælp eller har fast indtægt, lever af opsparing, har mistet sin indtægt eller låner penge af sit netværk. Problematikker omkring den økonomiske situation kan fx omfatte utilstrækkelige økonomiske ressourcer eller gæld. Ressourcer i forhold til den økonomiske situation kan fx være, at man er trygt stillet økonomisk."
        },
        {
          "code" : "35c56275-0093-4901-9fd8-d06fdb5cb8f3",
          "display" : "Boligsituation",
          "definition" : "En persons boligsituation er den samlede mængde af forhold, der bestemmer, hvordan en person er stillet med hensyn til bolig. Et eksempel på boligsituation kan fx være, at man bor til leje eller er opsagt, bor ude eller hjemme, mangler egen bolig og pt. bor hos personer i netværket osv. Problematikker i forhold til boligsituationen kan være uhensigtsmæssig indretning i forhold til beboerens behov, uhensigtsmæssig brug af boligen eller hjemløshed, hvor en person ikke har eller ikke kan opholde sig i egen bolig. Ressourcer i forhold til boligsituationen kan være, at ens bolig er indrettet hensigtsmæssigt i forhold til ens funktionsnedsættelse, eller at man kan blive boende i sin bolig, selvom en funktionsnedsættelse eller et socialt problem har betydet ændringer i ens indtægtsforhold."
        },
        {
          "code" : "52efa2e9-e0dc-41eb-8c01-9865e2fdebae",
          "display" : "Interesser",
          "definition" : "Interesser er de aktiviteter eller objekter, som en person beskæftiger sig indgående med og er optaget af. Interesser kan spænde over alle tænkelige forhold. Eksempler på problematikker vedrørende interesser kan være, at interessen tager overhånd og bliver for tidskrævende eller på anden vis er uhensigtsmæssig. Eksempler på ressourcer vedrørende interesser kan være, at interessen virker afstressende eller motiverende eller på anden vis bidrager positivt til livskvaliteten."
        },
        {
          "code" : "7a8f247b-baf8-4552-95bb-acf8ef004b74",
          "display" : "Familiesituation",
          "definition" : "En persons familiesituation er den samlede mængde af forhold, der bestemmer, hvordan en person er stillet med hensyn til familie. Et eksempel på familiesituation kan være, at man er gift eller samlevende, lever alene eller sammen med andre eller har børn. Problematikker vedrørende familiesituation kan fx være skilsmisse, uønsket social isolation, ufrivillig barnløshed eller en syg partner. Ressourcer vedrørende familiesituation kan være, at ens familiesituation er i overensstemmelse med ens egne ønsker og behov."
        },
        {
          "code" : "83cf43f1-6d71-477c-8583-2e28755b41d3",
          "display" : "Kriminalitet",
          "definition" : "Kriminalitet er en handling, der er strafbar. Kriminalitet som socialt problem er kendetegnet ved, at en person er, eller er i fare for at blive, marginaliseret."
        },
        {
          "code" : "d493a97d-6036-423d-87ff-c2a086e9d664",
          "display" : "Traumatiske oplevelser",
          "definition" : "Traumatiske oplevelser er konkrete oplevelser, der har belastende følger for en person. Eksempler på traumatiske oplevelser er omsorgssvigt, ulykker og overgreb."
        },
        {
          "code" : "e993d8c3-b7d7-4d72-9be2-937e5ba38b5a",
          "display" : "Prostitution",
          "definition" : "Prostitution er en handling, hvor mindst to handlende personer på markedsmæssige betingelser henholdsvis køber og sælger en prostitutionsydelse mod betaling. Prostitution som socialt problem er kendetegnet ved, at en person er, eller er i fare for at blive, marginaliseret. Den tankemæssige forestilling om fænomenet prostitution er værdineutral. Inden for Servicelovens område er prostitution benævnt som type af socialt problem, men hvorvidt prostitution udgør et problem for den enkelte må afgøres på individniveau. Begrebet omfatter ikke forhold, der falder under de strafferetlige regler, fx køb af seksuelle ydelser, der sælges af unge under 18 år, eller det fænomen, at personer tvinges af andre til at sælge seksuelle ydelser."
        },
        {
          "code" : "f695cec7-2b39-4c7e-8731-da8558a4fb3f",
          "display" : "Uddannelse og job",
          "definition" : "En persons uddannelses og job er den samlede mængde af forhold, der bestemmer, hvordan en person er stillet med hensyn til uddannelsesniveau og arbejde. Arbejde dækker bredt, fx både ordinært arbejde, frivilligt arbejde eller beskæftigelsestilbud. Et eksempel på uddannelses- og jobsituation kan være en gennemført ungdomsuddannelse, igangværende enkeltfagskurser, ledighed, fast arbejde eller frivilligt arbejde. Problematikker i relation til uddannelse og job kan være ledighed eller højt fravær fra studierne. Ressourcer i relation til uddannelse og job kan fx være, at man har en uddannelse eller gode erfaringer med job og beskæftigelse."
        }]
      }]
    },
    {
      "code" : "93433530-b85c-4d04-a4fb-5ae26cf16f1c",
      "display" : "Aktivitet og deltagelse",
      "definition" : "Aktivitet og deltagelse",
      "concept" : [{
        "code" : "3856b434-f72e-42a5-b9d1-0cc93f48434b",
        "display" : "Relationer",
        "definition" : "Relationer vedrører en persons relationer til og interaktion med andre mennesker. Relationer til andre dækker både over evnen til at indgå og bevare relationer til andre mennesker, såvel som deltagelse i organiseret socialt liv uden for familien, i lokalsamfundet i det sociale liv og som medborger.",
        "concept" : [{
          "code" : "3f9da5ac-9686-4eeb-b517-b46e17fcb1d7",
          "display" : "Indgå i samspil og kontakt",
          "definition" : "At indgå i samspil og kontakt er en aktivitet, som består i at indgå i enkle eller komplekse relationer med mennesker på en måde, der er kontekstuelt og socialt passende. Begrebet har fokus på evnen til at indgå i relationer. Det vil fx sige at kunne vise hensyn og respekt, når det er passende eller reagere på andres følelser og indgå i samspil med andre mennesker (fremmede, venner, slægtninge, familiemedlemmer og kærester) fx ved at kunne give og modtage kritik, reagere på sociale signaler, anvende passende fysisk kontakt i sammenhængen, styre følelser og impulser, styre verbale og fysiske aggressioner og handle i overensstemmelse med sociale regler og konventioner."
        },
        {
          "code" : "4c082610-b122-4019-96f2-1061e287445e",
          "display" : "Varetage relationer til netværk",
          "definition" : "At varetage relationer til netværk er en handling, der består i at skabe og opretholde et netværk. Relationerne til de enkelte personer i netværket kan både være af formel og uformel karakter, fx relationer til professionelle fagpersoner og relationer til venner, naboer, bekendte og ligesindede."
        },
        {
          "code" : "dcc6bb77-45af-4625-9c4d-7d7878307220",
          "display" : "Deltage i sociale fællesskaber og fritidsaktiviteter",
          "definition" : "At deltage i sociale fællesskaber er en handling, der består i at deltage i organiseret socialt liv uden for familien, i lokalsamfundet, i det sociale liv og som medborger. Begrebet har fokus på en persons evne til og mulighed for at deltage i fællesskaber og frivilligt arbejde, herunder fx rekreative aktiviteter og fritidsaktiviteter, religiøse eller åndelige fællesskaber samt politisk liv."
        }]
      },
      {
        "code" : "c2b186f9-9c10-478e-8345-2d2c37ab4c46",
        "display" : "Kommunikation",
        "definition" : "Kommunikation er en proces, der består af en overførsel eller udveksling af information. Begrebet rummer almindelige og særlige forhold i kommunikation med sprog, tegn og symboler, inklusive modtagelse og fremstilling af meddelelser, føre en samtale og anvende kommunikationshjælpemidler og -teknikker.",
        "concept" : [{
          "code" : "2ba29098-a527-43d5-b858-4c5353669f42",
          "display" : "Fremstille meddelelser",
          "definition" : "At fremstille meddelelser er en aktivitet, der består i at fremsætte meddelelser med bogstavelige og underforståede betydninger mundtligt eller ved at anvende fagter, tegn, tegninger eller formaliseret tegnsprog eller skrift. Med formidling af meddelelser menes fx at gøre rede for kendsgerninger eller fortælle en historie, udtrykke uenighed eller forklare kendsgerninger eller komplekse tanker, samt at kunne meddele sig ved hjælp af kropssprog, almindelige tegn, symboler og billeder."
        },
        {
          "code" : "986898d0-e2e5-4afa-9cb3-ee7aecaa0143",
          "display" : "Samtale",
          "definition" : "Samtale er en aktivitet, der består i at indlede, opretholde og afslutte udveksling af tanker og ideer frembragt enten i talesprog, tegnsprog eller med andre sprog mellem en eller flere personer."
        },
        {
          "code" : "9bbbffef-c404-4ea3-a927-cd22d8027e6d",
          "display" : "Forstå meddelelser",
          "definition" : "At forstå meddelelser er en aktivitet, der består i at forstå bogstavelige og underforståede meninger i talesprog eller i meddelelser, som formidles med fagter, symboler og tegninger i formaliseret tegnsprog eller på skrift. Med forstå menes fx at skelne om en udtalelse udtrykker en kendsgerning eller er et billedligt udtryk, samt at kunne forstå betydningen af kropssprog, almindelige tegn, symboler og billeder."
        },
        {
          "code" : "a80e8f96-18ba-4ee4-9496-d3ce882c2f85",
          "display" : "Anvende kommunikationsudstyr- og teknikker",
          "definition" : "At anvende kommunikationsudstyr og -teknikker er en aktivitet, der består i at anvende udstyr og teknikker med kommunikationsformål. Kommunikationsudstyr omfatter også kommunikationshjælpemidler. Eksempler på udstyr er fx telefon, sms og computer, et eksempel på teknik er Braille og mundaflæsning."
        }]
      },
      {
        "code" : "d1495b2c-1452-4e49-8dbe-8193af5d8823",
        "display" : "Mobilitet",
        "definition" : "Mobilitet er en aktivitet, der vedrører bevægelse og færden. Det kan fx være ændring eller opretholdelse af kropsstilling eller -placering eller bevægelse fra ét sted til et andet, flytning og håndtering af genstande, færden ved gang, løb eller klatring og ved anvendelse af forskellige transportmidler.",
        "concept" : [{
          "code" : "320c9aa6-630e-4695-bba2-29ea808fad24",
          "display" : "Bære, flytte og håndtere genstande",
          "definition" : "At bære, flytte og håndtere genstande er en aktivitet, der består i at løfte en genstand op og flytte noget fra ét sted til et andet ved hjælp af hænder, arme eller ben."
        },
        {
          "code" : "4977ce08-df4d-4c09-8e03-c2a563862e68",
          "display" : "Gå og bevæge sig",
          "definition" : "At gå og bevæge sig er en aktivitet, der består i at bevæge sig fra et sted til et andet i forskellige omgivelser. Begrebet rummer også færden med brug af udstyr, fx kørestol eller gangstativ."
        },
        {
          "code" : "759ddc8e-57c0-4aa6-8d32-14d8eb51c5dd",
          "display" : "Ændre og opretholde kropsstilling",
          "definition" : "At ændre og opretholde kropsstilling er en aktivitet, der består i at skifte kropsstilling eller holde kroppen i samme stilling efter behov. Begrebet rummer også at flytte sig fra et sted til et andet og skifte eller bevare kropsstilling undervejs."
        },
        {
          "code" : "eff3385d-01fa-4c9c-9850-52e179243f21",
          "display" : "Færdes med transportmidler",
          "definition" : "At færdes med transportmidler en en aktivitet, der består i at bruge transportmidler som passager eller chauffør til at komme omkring."
        }]
      },
      {
        "code" : "da3f488f-1742-4d00-b247-a7d47500b36b",
        "display" : "Egenomsorg",
        "definition" : "Egenomsorg er en aktivitet, der vedrører praktiske og hygiejnemæssige handlinger i relation til personen selv. Handlingerne kan fx være vaske og tørre sig, pleje af kroppen og kropsdele, påklædning, spise og drikke og tage vare på egen sundhed.",
        "concept" : [{
          "code" : "14615a09-bd94-4602-b43a-f6d3d3f9801d",
          "display" : "Drikke",
          "definition" : "At drikke er en aktivitet, der består i at holde fast om en drik, tage drikken op til munden og drikke på en kulturelt accepteret måde. Begrebet rummer også at blande, omrøre og skænke drikke op, åbne flasker og dåser og bruge sugerør."
        },
        {
          "code" : "28fbf17e-bca3-45e1-be35-553e3d91f1b7",
          "display" : "Varetage sin seksualitet",
          "definition" : "At varetage sin seksualitet handler om, hvorvidt en persons funktionsnedsættelse eller sociale problemer giver begrænsninger i forhold til at udleve ens seksualitet."
        },
        {
          "code" : "347aa085-4fe2-411f-ac56-5693d164adc3",
          "display" : "Klæde sig af og på",
          "definition" : "At klæde sig af og på er en aktivitet, der består i at tage tøj og sko af og på i rækkefølge og i overensstemmelse med den sociale sammenhæng og de klimatiske forhold."
        },
        {
          "code" : "3a748135-98a8-416a-808d-bff88a8e40ee",
          "display" : "Dyrke interesse",
          "definition" : "At dyrke en interesse er en handling, der består i at bruge tid og energi på en bestemt aktivitet eller ting, som man er optaget af. Det kan fx være at samle på bestemte ting, spille computerspil eller lave håndarbejde."
        },
        {
          "code" : "464a2ab6-a7df-4b3a-b74d-7873f4cfe668",
          "display" : "Spise",
          "definition" : "At spise er en aktivitet af sammensat karakter i forbindelse med indtagelse af føde, som er serveret for en, herunder at få maden op til munden og spise på en kulturelt accepteret måde. Begrebet rummer også at skære eller bryde maden i stykker, åbne flasker og dåser, anvende spiseredskaber, deltage i måltider og i festligheder."
        },
        {
          "code" : "4a58417e-9a75-43f2-9763-66505050159f",
          "display" : "Varetage egen sundhed",
          "definition" : "At varetage egen sundhed er en handling, der består i at sikre sit velvære, helbred og fysiske og psykiske velbefindende. Varetagelse af egen sundhed omfatter fx at tage vare på sig selv ved at være opmærksom på, at man har brug for og skal gøre det, der er nødvendigt til varetagelse af egen sundhed, både ved at reagere på risikofaktorer og forebygge sygdom ved fx at opsøge professionel hjælp, følge medicinsk behandling og lægelige og andre råd om sundhed, undgå risikofaktorer som fysiske skader, smitsomme sygdomme, misbrug og seksuelt overførbare sygdomme."
        },
        {
          "code" : "885400cc-dd71-479e-8993-3fc48fdd6710",
          "display" : "Vaske sig",
          "definition" : "At vaske sig er en aktivitet, der der består i at vaske og tørre sig på kroppen og kropsdele med anvendelse af vand og passende rensemidler. Eksempler på vask er bad, brusebad, vaske hænder og fødder, ansigt og hår og tørre sig med håndklæde."
        },
        {
          "code" : "94fb3ea0-92cf-43b1-929b-c95e6fb739a1",
          "display" : "Gå på toilettet",
          "definition" : "At gå på toilettet er en aktivitet, der består i at planlægge og udføre toiletbesøg til udskillelse af affaldsprodukter og efterfølgende rengøring."
        },
        {
          "code" : "b3939f0b-43d9-4e8c-bb2e-50ff8bb7ed03",
          "display" : "Pleje sin krop",
          "definition" : "At pleje sin krop er en aktivitet, der består i at pleje de dele af kroppen, som behøver anden pleje end vask og tørring. Begrebet rummer fx pleje af hud, ansigt, tænder, hår, negle og kønsdele."
        }]
      },
      {
        "code" : "dfbe6ff6-223b-436a-b864-8ba29bda41e2",
        "display" : "Samfundsliv",
        "definition" : "Samfundsliv er forhold, der vedrører de opgaver og handlinger, som er nødvendige for at varetage uddannelse, beskæftigelse og økonomi.",
        "concept" : [{
          "code" : "685e8517-2f5c-4ef8-a7c4-fa2d008fdd9d",
          "display" : "Varetage beskæftigelse",
          "definition" : "Varetage beskæftigelse er en handling, der består i at deltage i alle aspekter af et arbejde, erhverv eller anden for for beskæftigelse som ansat på fuldtid eller deltid eller som selvstændig. Eksempler på aspekter er at søge et arbejde og få det, udføre de nødvendige opgaver i jobbet, møde på arbejde til tiden, lede andre arbejdere eller selv blive ledet samt at udføre de nødvendige opgaver alene eller i gruppe."
        },
        {
          "code" : "70443014-3faf-402d-abcf-396bfad32eb9",
          "display" : "Varetage økonomi",
          "definition" : "At varetage økonomi er en handling, der består i at varetage opgaver i relation til ens økonomi. Begrebet omfatter varetagelse af basale økonomiske transaktioner som fx at betale for varer eller have overblik over faste udgifter, spare op eller benytte netbank."
        },
        {
          "code" : "8888edfa-642b-4329-9fe3-a9b180e6d3f4",
          "display" : "Varetage uddannelse",
          "definition" : "Varetage uddannelse er et struktureret kompetencegivende undervisningsforløb, der kvalificerer modtageren til fortsat uddannelse eller til at udøve et bestemt erhverv eller udføre en bestemt opgave. Begrebet rummer skolegang, erhvervsuddannelse og videregående uddannelse."
        },
        {
          "code" : "8bef71de-55b5-47fe-b438-18ac769106b3",
          "display" : "Håndtere post",
          "definition" : "At håndtere post er en handling, der omfatter at tjekke, om der er fysisk eller digital post og at reagere på modtaget post og følge op herpå."
        },
        {
          "code" : "fd4b8dd3-5c4b-4257-8c13-ea045617d2f6",
          "display" : "Varetage bolig",
          "definition" : "At varetage bolig er en handling, der består i at leje eller købe, møblere, indrette og fastholde et hus, en lejlighed eller anden bolig. Fastholdelse af bolig kan eksempelvis være at efterleve en eventuel husorden eller deltage i fællesopgaver. At varetage bolig inkluderer også at flytte ud af en bolig igen."
        }]
      },
      {
        "code" : "eef71492-65f5-4297-aa95-3c3a6866ddef",
        "display" : "Praktiske opgaver",
        "definition" : "Opgaver i hjemmet er en aktivitet, der vedrører huslige og andre dagligdags handlinger og opgaver i relation til husførelse.",
        "concept" : [{
          "code" : "01770afa-cd17-41fe-a966-b8895e4d55d8",
          "display" : "Købe ind",
          "definition" : "Indkøb er en handling, der består i at købe varer og serviceydelser, som er nødvendige i dagligdagen. Begrebet inkluderer også at instruere og vejlede en anden person i at foretage indkøbene, som fx at vælge madvarer, drikke, rengøringsmidler, husholdningsartikler i en forretning, på et marked eller på nettet; sammenligne kvalitet og pris af varerne, forhandle og betale for de valgte varer eller ydelser og transportere varerne."
        },
        {
          "code" : "4a51d7a7-61e7-48fa-a1d5-9d26337c6c38",
          "display" : "Passe ejendele",
          "definition" : "Udførsel af praktiske opgaver er en handling, der består i at vedligeholde og reparere personlige ejendele. Handlingen omfatter fx vedligehold og reparation af beklædning, bolig, indbo, køretøjer og hjælpemidler som fx ved at male og tapetsere, reparere møbler og installationer, sikre at køretøjer virker, passe og fodre kæledyr og husdyr samt vande planter."
        },
        {
          "code" : "58ef570c-1c1e-47be-8bfd-26ed99825762",
          "display" : "Udvise hjælp og omsorg for andre",
          "definition" : "At udvise hjælp og omsorg for andre er en handling, der består i at hjælpe medlemmer i husstanden og andre. Begrebet rummer også at hjælpe andre med indlæring, kommunikation, egenomsorg, færden inde og ude samt at være opmærksom på andres velbefindende. Et eksempel på at hjælpe og drage omsorg for andre er varetagelse af forældrerollen."
        },
        {
          "code" : "8f32c948-41c4-49d7-8913-cdeede2e7fe1",
          "display" : "Gøre rent",
          "definition" : "At gøre rent er en handling, der består i at holde ens nære fysiske omgivelser rene og hygiejniske. Rengøring kan fx ske ved at støvsuge, vaske gulv og støve af og omfatter typisk oprydning."
        },
        {
          "code" : "b947f321-7cdb-4b33-9653-f3ff800572b0",
          "display" : "Lave mad",
          "definition" : "At lave mad er en handling, der består i at planlægge, tilberede og servere enkle eller sammensatte måltider. Handlingen kan fx bestå i at sammensætte et måltid, udvælge appetitlig mad og drikke, fremskaffe ingredienser til tilberedning af måltider; forberede mad og drikke til tilberedning, lave varm og kold mad og drikke samt at servere maden til sig selv eller andre."
        },
        {
          "code" : "bd67597b-e80f-427f-8cf9-79d01eff91fc",
          "display" : "Vaske tøj",
          "definition" : "At vaske tøj er en handling, der består i at holde ens tøj rent ved at vaske det, når det trænger. At vaske tøj omfatter fx at sortere vasketøj, sætte en vask over, tørre tøj og lægge det rene tøj sammen og på plads."
        }]
      }]
    },
    {
      "code" : "a56d59c0-c8fd-468c-85f9-b67f66561b90",
      "display" : "Omgivelsesfaktorer",
      "definition" : "Omgivelsesfaktorer",
      "concept" : [{
        "code" : "7445fb2b-0009-43d9-b49b-1b9782f2fcd9",
        "display" : "Omgivelser",
        "definition" : "Omgivelser er en kontekstuel faktor, der omfatter de fysiske, sociale og holdningsmæssige omgivelser, som en person bor og lever i. Omgivelsesfaktorer omfatter hele den omgivende verden, som danner rammen for en persons tilværelse, og som kan hæmme eller fremme personens funktionsevne. Omgivelsesfaktorer omfatter de fysiske omgivelser, de menneskeskabte omgivelser, de kulturelle omgivelser, som fx roller, holdninger og værdier samt sociale omgivelser, som fx politiske forhold, forordninger og formelle regler. På det personlige niveau kan omgivelsesfaktorer fx være hjem, arbejdsplads og skole og den personlige kontakt med fx familie, bekendte, kollegaer og fremmede. På det samfundsmæssige niveau kan omgivelsesfaktorer fx være sociale strukturer som organisationer og offentlige institutioner, tjenester, ydelser, fællesskabsaktiviteter, love og regler samt holdninger og ideologier.",
        "concept" : [{
          "code" : "22eef871-6650-426f-8b79-8d40a6c62808",
          "display" : "Holdninger i omgivelserne",
          "definition" : "Holdninger i omgivelserne er ideologier, værdier, normer, faktuelle og religiøse overbevisninger i en persons omgivelser, der afføder vaner, praksisser og andre synlige konsekvenser, som kan påvirke den enkeltes adfærd og sociale liv på alle planer. En persons omgivelser er fx familie, slægtninge, venner, bekendte, omsorgsgivere, personlige hjælpere, fremmede, sundhedspersonale, andre professionelle, samfundet og sociale normer, konventioner og ideologier."
        },
        {
          "code" : "83342ff3-5f2e-4914-b045-e98357685866",
          "display" : "Boligområde",
          "definition" : "Et boligområde er en ramme, der udgør en persons nærmiljø, herunder art og betydning af socialgrupper, bebyggelse og infrastruktur i samme geografiske område."
        },
        {
          "code" : "df194a84-6e4b-4f14-a194-d8d9d9a1fcad",
          "display" : "Personer i netværk",
          "definition" : "Netværk er en eller flere personer, der giver praktisk eller følelsesmæssig støtte, omsorg, beskyttelse, hjælp og kontakt til andre mennesker. Begrebet har fokus på de personer, der udgør et netværk. Begrebet har fokus på de personer, der udgør et netværk. Et netværk kan være privat, professionelt eller bestå af frivilligt organiserede personer. Et professionelt netværk kan fx bestå af skolelærere, sagsbehandlere, personlige hjælpere, sundhedspersonale og andre professionelle. Et privat netværk er familie, slægtninge, venner eller bekendtskaber. Et netværk bestående af frivilligt organiserede personer kan fx udgøres af fodboldtrænere eller spejderlederer. Støtte mv. gives i hjemmet, på arbejdspladsen, i skolen, under leg eller i andre forhold i en persons daglige aktivitet. Et velfungerende netværk er en ressource for en person, hvor i mod et netværk også kan være uhensigtsmæssigt og dermed påvirke en person i negativ retning."
        }]
      }]
    }]
  },
  {
    "code" : "b5257b2d-0fbf-4d00-bf38-d298c8568116",
    "display" : "Måltype",
    "definition" : "Måltype er en type af mål, der præciserer forventningen til den bevægelse, der er frem mod den ønskede tilstand, som målet er udtryk for. Måltypen bestemmes ud fra en vurdering af en persons mulighed for at udvikle, fastholde eller begrænse tab af funktionsevne. Måltypen siger ikke noget om, hvilket specifikt funktionsevneniveau personen vurderes at opnå. Måltype kan fx anvendes i forventningsafstemning mellem borger, myndighed og udfører i forbindelse med koordinering af den sociale indsats.",
    "concept" : [{
      "code" : "10752a63-00b4-4958-b7f4-9f3a18f74266",
      "display" : "Fastholde funktionsevne",
      "definition" : "Fastholde funktionsevne er en måltype, der er udtryk for en forventning om, at borgeren støttes i at fastholde sin funktionsevne i relation til målet. Fastholde funktionsevne i relation til målet indebærer, at borgeren fortsat kan udføre de samme aktiviteter og med samme hyppighed som hidtil."
    },
    {
      "code" : "d41c8072-52f8-42b5-9375-ddbea454d27f",
      "display" : "Udvikle funktionsevne",
      "definition" : "Udvikle funktionsevne er en måltype, der er udtryk for en forventning om, at borgeren støttes i at udvikle sin funktionsevne i relation til målet. Udvikle funktionsevne i relation til målet indebærer, at borgeren opnår at kunne udføre flere aktiviteter oftere end hidtil."
    },
    {
      "code" : "e47c22bd-d88d-48ab-882b-419923e1f44e",
      "display" : "Begrænse tab af funktionsevne",
      "definition" : "Begrænse tab af funktionsevne er en måltype, der er udtryk for en forventning om, at der vil være et tab af funktionsevne i relation til målet, men at borgeren støttes i at begrænse sit tab af funktionsevne i relation til målet mest muligt. Begrænse tab af funktionsevne i relation til målet indebærer, at borgeren i mindst mulig grad mister evnen til at udføre aktiviteter i samme omfang og med samme hyppighed som hidtil."
    }]
  },
  {
    "code" : "e89d317c-4657-4970-b614-ada2ed220595",
    "display" : "Funktionsevneniveau",
    "definition" : "Funktionsevneniveau",
    "concept" : [{
      "code" : "1c327095-107f-4b96-88d0-ec562cb980be",
      "display" : "Ikke vurderet",
      "definition" : "Ikke vurderet"
    },
    {
      "code" : "5bdde847-2837-416b-ab63-bbff8b7aa531",
      "display" : "Moderat nedsat funktionsevne",
      "definition" : "Moderat nedsat funktionsevne"
    },
    {
      "code" : "8328ce4a-6238-4f73-bf1a-74aadb68eff8",
      "display" : "Let nedsat funktionsevne",
      "definition" : "Let nedsat funktionsevne"
    },
    {
      "code" : "832ae90b-23b5-4063-80aa-0b81bdce680e",
      "display" : "Fuldstændig nedsat funktionsevne",
      "definition" : "Fuldstændig nedsat funktionsevne"
    },
    {
      "code" : "b508ff66-6326-4862-a6d7-7bbf184c9823",
      "display" : "Ingen nedsat funktionsevne",
      "definition" : "Ingen nedsat funktionsevne"
    },
    {
      "code" : "cae545f5-2813-4d79-98fc-0a7d770af3cd",
      "display" : "Svært nedsat funktionsevne",
      "definition" : "Svært nedsat funktionsevne"
    }]
  }]
}

```
